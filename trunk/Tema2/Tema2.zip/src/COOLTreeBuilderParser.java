// $ANTLR 3.2 Sep 23, 2009 12:02:23 ./src/COOLTreeBuilder.g 2009-11-15 23:00:51

import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import org.antlr.runtime.tree.*;

public class COOLTreeBuilderParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "CLASS_T", "BLOCK_T", "CALL_T", "FEATURES_T", "ASSIGN_T", "METHOD_T", "BOOL_T", "EXPR_T", "RETURN_TYPE_T", "TYPE_ID", "FORMALS_T", "ATTR_T", "ID_T", "INTEGER_T", "OP_T", "CLASS_ST", "TYPE", "INHERITS_ST", "ID", "NOT_ST", "ISVOID_ST", "INTEGER", "TRUE_ST", "FALSE_ST", "STRING", "NEW_ST", "IF_ST", "THEN_ST", "ELSE_ST", "FI_ST", "WHILE_ST", "LOOP_ST", "POOL_ST", "CASE_ST", "OF_ST", "ESAC_ST", "LET_ST", "IN_ST", "MULTI_COMMENT", "SINGLE_COMMENT", "ESC_SEQ", "WS", "';'", "'{'", "'}'", "'('", "','", "')'", "':'", "'<-'", "'<='", "'<'", "'='", "'+'", "'-'", "'*'", "'/'", "'~'", "'@'", "'.'", "'=>'"
    };
    public static final int T__64=64;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int TRUE_ST=26;
    public static final int CLASS_T=4;
    public static final int LET_ST=40;
    public static final int CLASS_ST=19;
    public static final int MULTI_COMMENT=42;
    public static final int FI_ST=33;
    public static final int T__61=61;
    public static final int ID=22;
    public static final int T__60=60;
    public static final int EOF=-1;
    public static final int IN_ST=41;
    public static final int LOOP_ST=35;
    public static final int TYPE=20;
    public static final int EXPR_T=11;
    public static final int T__55=55;
    public static final int NOT_ST=23;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int INTEGER_T=17;
    public static final int T__58=58;
    public static final int ESC_SEQ=44;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__59=59;
    public static final int ASSIGN_T=8;
    public static final int INHERITS_ST=21;
    public static final int SINGLE_COMMENT=43;
    public static final int ATTR_T=15;
    public static final int BLOCK_T=5;
    public static final int T__50=50;
    public static final int INTEGER=25;
    public static final int T__46=46;
    public static final int WHILE_ST=34;
    public static final int T__47=47;
    public static final int FEATURES_T=7;
    public static final int OF_ST=38;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int ELSE_ST=32;
    public static final int METHOD_T=9;
    public static final int BOOL_T=10;
    public static final int POOL_ST=36;
    public static final int OP_T=18;
    public static final int RETURN_TYPE_T=12;
    public static final int IF_ST=30;
    public static final int ID_T=16;
    public static final int ISVOID_ST=24;
    public static final int CASE_ST=37;
    public static final int ESAC_ST=39;
    public static final int WS=45;
    public static final int NEW_ST=29;
    public static final int FALSE_ST=27;
    public static final int CALL_T=6;
    public static final int TYPE_ID=13;
    public static final int FORMALS_T=14;
    public static final int STRING=28;
    public static final int THEN_ST=31;

    // delegates
    // delegators


        public COOLTreeBuilderParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public COOLTreeBuilderParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return COOLTreeBuilderParser.tokenNames; }
    public String getGrammarFileName() { return "./src/COOLTreeBuilder.g"; }




    public static class program_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "program"
    // ./src/COOLTreeBuilder.g:31:1: program : ( class_stat ';' )+ -> ( ^( class_stat ) )+ ;
    public final COOLTreeBuilderParser.program_return program() throws RecognitionException {
        COOLTreeBuilderParser.program_return retval = new COOLTreeBuilderParser.program_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal2=null;
        COOLTreeBuilderParser.class_stat_return class_stat1 = null;


        CommonTree char_literal2_tree=null;
        RewriteRuleTokenStream stream_46=new RewriteRuleTokenStream(adaptor,"token 46");
        RewriteRuleSubtreeStream stream_class_stat=new RewriteRuleSubtreeStream(adaptor,"rule class_stat");
        try {
            // ./src/COOLTreeBuilder.g:32:2: ( ( class_stat ';' )+ -> ( ^( class_stat ) )+ )
            // ./src/COOLTreeBuilder.g:33:2: ( class_stat ';' )+
            {
            // ./src/COOLTreeBuilder.g:33:2: ( class_stat ';' )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==CLASS_ST) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // ./src/COOLTreeBuilder.g:33:3: class_stat ';'
            	    {
            	    pushFollow(FOLLOW_class_stat_in_program266);
            	    class_stat1=class_stat();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_class_stat.add(class_stat1.getTree());
            	    char_literal2=(Token)match(input,46,FOLLOW_46_in_program268); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_46.add(char_literal2);


            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);



            // AST REWRITE
            // elements: class_stat
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 33:20: -> ( ^( class_stat ) )+
            {
                if ( !(stream_class_stat.hasNext()) ) {
                    throw new RewriteEarlyExitException();
                }
                while ( stream_class_stat.hasNext() ) {
                    // ./src/COOLTreeBuilder.g:33:23: ^( class_stat )
                    {
                    CommonTree root_1 = (CommonTree)adaptor.nil();
                    root_1 = (CommonTree)adaptor.becomeRoot(stream_class_stat.nextNode(), root_1);

                    adaptor.addChild(root_0, root_1);
                    }

                }
                stream_class_stat.reset();

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "program"

    public static class class_stat_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "class_stat"
    // ./src/COOLTreeBuilder.g:36:1: class_stat : CLASS_ST name= TYPE ( INHERITS_ST baseClass= TYPE )? '{' ( feature ';' )* '}' -> ^( CLASS_T $name ( $baseClass)? ^( FEATURES_T ( feature )* ) ) ;
    public final COOLTreeBuilderParser.class_stat_return class_stat() throws RecognitionException {
        COOLTreeBuilderParser.class_stat_return retval = new COOLTreeBuilderParser.class_stat_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token name=null;
        Token baseClass=null;
        Token CLASS_ST3=null;
        Token INHERITS_ST4=null;
        Token char_literal5=null;
        Token char_literal7=null;
        Token char_literal8=null;
        COOLTreeBuilderParser.feature_return feature6 = null;


        CommonTree name_tree=null;
        CommonTree baseClass_tree=null;
        CommonTree CLASS_ST3_tree=null;
        CommonTree INHERITS_ST4_tree=null;
        CommonTree char_literal5_tree=null;
        CommonTree char_literal7_tree=null;
        CommonTree char_literal8_tree=null;
        RewriteRuleTokenStream stream_48=new RewriteRuleTokenStream(adaptor,"token 48");
        RewriteRuleTokenStream stream_INHERITS_ST=new RewriteRuleTokenStream(adaptor,"token INHERITS_ST");
        RewriteRuleTokenStream stream_47=new RewriteRuleTokenStream(adaptor,"token 47");
        RewriteRuleTokenStream stream_46=new RewriteRuleTokenStream(adaptor,"token 46");
        RewriteRuleTokenStream stream_CLASS_ST=new RewriteRuleTokenStream(adaptor,"token CLASS_ST");
        RewriteRuleTokenStream stream_TYPE=new RewriteRuleTokenStream(adaptor,"token TYPE");
        RewriteRuleSubtreeStream stream_feature=new RewriteRuleSubtreeStream(adaptor,"rule feature");
        try {
            // ./src/COOLTreeBuilder.g:37:2: ( CLASS_ST name= TYPE ( INHERITS_ST baseClass= TYPE )? '{' ( feature ';' )* '}' -> ^( CLASS_T $name ( $baseClass)? ^( FEATURES_T ( feature )* ) ) )
            // ./src/COOLTreeBuilder.g:38:2: CLASS_ST name= TYPE ( INHERITS_ST baseClass= TYPE )? '{' ( feature ';' )* '}'
            {
            CLASS_ST3=(Token)match(input,CLASS_ST,FOLLOW_CLASS_ST_in_class_stat290); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_CLASS_ST.add(CLASS_ST3);

            name=(Token)match(input,TYPE,FOLLOW_TYPE_in_class_stat294); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_TYPE.add(name);

            // ./src/COOLTreeBuilder.g:38:21: ( INHERITS_ST baseClass= TYPE )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==INHERITS_ST) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:38:22: INHERITS_ST baseClass= TYPE
                    {
                    INHERITS_ST4=(Token)match(input,INHERITS_ST,FOLLOW_INHERITS_ST_in_class_stat297); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_INHERITS_ST.add(INHERITS_ST4);

                    baseClass=(Token)match(input,TYPE,FOLLOW_TYPE_in_class_stat301); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_TYPE.add(baseClass);


                    }
                    break;

            }

            char_literal5=(Token)match(input,47,FOLLOW_47_in_class_stat305); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_47.add(char_literal5);

            // ./src/COOLTreeBuilder.g:38:55: ( feature ';' )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( (LA3_0==ID) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // ./src/COOLTreeBuilder.g:38:56: feature ';'
            	    {
            	    pushFollow(FOLLOW_feature_in_class_stat308);
            	    feature6=feature();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) stream_feature.add(feature6.getTree());
            	    char_literal7=(Token)match(input,46,FOLLOW_46_in_class_stat310); if (state.failed) return retval; 
            	    if ( state.backtracking==0 ) stream_46.add(char_literal7);


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);

            char_literal8=(Token)match(input,48,FOLLOW_48_in_class_stat314); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_48.add(char_literal8);



            // AST REWRITE
            // elements: baseClass, feature, name
            // token labels: baseClass, name
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleTokenStream stream_baseClass=new RewriteRuleTokenStream(adaptor,"token baseClass",baseClass);
            RewriteRuleTokenStream stream_name=new RewriteRuleTokenStream(adaptor,"token name",name);
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 39:3: -> ^( CLASS_T $name ( $baseClass)? ^( FEATURES_T ( feature )* ) )
            {
                // ./src/COOLTreeBuilder.g:39:6: ^( CLASS_T $name ( $baseClass)? ^( FEATURES_T ( feature )* ) )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CLASS_T, "CLASS_T"), root_1);

                adaptor.addChild(root_1, stream_name.nextNode());
                // ./src/COOLTreeBuilder.g:39:22: ( $baseClass)?
                if ( stream_baseClass.hasNext() ) {
                    adaptor.addChild(root_1, stream_baseClass.nextNode());

                }
                stream_baseClass.reset();
                // ./src/COOLTreeBuilder.g:39:34: ^( FEATURES_T ( feature )* )
                {
                CommonTree root_2 = (CommonTree)adaptor.nil();
                root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FEATURES_T, "FEATURES_T"), root_2);

                // ./src/COOLTreeBuilder.g:39:47: ( feature )*
                while ( stream_feature.hasNext() ) {
                    adaptor.addChild(root_2, stream_feature.nextTree());

                }
                stream_feature.reset();

                adaptor.addChild(root_1, root_2);
                }

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "class_stat"

    public static class feature_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "feature"
    // ./src/COOLTreeBuilder.g:42:1: feature : ( ID '(' ( formal ( ',' formal )* )? ')' ':' type= TYPE '{' expr '}' -> ^( METHOD_T ID TYPE ^( FORMALS_T ( formal )* ) ^( EXPR_T expr ) ) | ID ':' TYPE ( '<-' expr )? -> ^( ATTR_T ID TYPE ( ^( EXPR_T expr ) )? ) );
    public final COOLTreeBuilderParser.feature_return feature() throws RecognitionException {
        COOLTreeBuilderParser.feature_return retval = new COOLTreeBuilderParser.feature_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token type=null;
        Token ID9=null;
        Token char_literal10=null;
        Token char_literal12=null;
        Token char_literal14=null;
        Token char_literal15=null;
        Token char_literal16=null;
        Token char_literal18=null;
        Token ID19=null;
        Token char_literal20=null;
        Token TYPE21=null;
        Token string_literal22=null;
        COOLTreeBuilderParser.formal_return formal11 = null;

        COOLTreeBuilderParser.formal_return formal13 = null;

        COOLTreeBuilderParser.expr_return expr17 = null;

        COOLTreeBuilderParser.expr_return expr23 = null;


        CommonTree type_tree=null;
        CommonTree ID9_tree=null;
        CommonTree char_literal10_tree=null;
        CommonTree char_literal12_tree=null;
        CommonTree char_literal14_tree=null;
        CommonTree char_literal15_tree=null;
        CommonTree char_literal16_tree=null;
        CommonTree char_literal18_tree=null;
        CommonTree ID19_tree=null;
        CommonTree char_literal20_tree=null;
        CommonTree TYPE21_tree=null;
        CommonTree string_literal22_tree=null;
        RewriteRuleTokenStream stream_49=new RewriteRuleTokenStream(adaptor,"token 49");
        RewriteRuleTokenStream stream_48=new RewriteRuleTokenStream(adaptor,"token 48");
        RewriteRuleTokenStream stream_47=new RewriteRuleTokenStream(adaptor,"token 47");
        RewriteRuleTokenStream stream_51=new RewriteRuleTokenStream(adaptor,"token 51");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_52=new RewriteRuleTokenStream(adaptor,"token 52");
        RewriteRuleTokenStream stream_53=new RewriteRuleTokenStream(adaptor,"token 53");
        RewriteRuleTokenStream stream_TYPE=new RewriteRuleTokenStream(adaptor,"token TYPE");
        RewriteRuleTokenStream stream_50=new RewriteRuleTokenStream(adaptor,"token 50");
        RewriteRuleSubtreeStream stream_formal=new RewriteRuleSubtreeStream(adaptor,"rule formal");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        try {
            // ./src/COOLTreeBuilder.g:43:2: ( ID '(' ( formal ( ',' formal )* )? ')' ':' type= TYPE '{' expr '}' -> ^( METHOD_T ID TYPE ^( FORMALS_T ( formal )* ) ^( EXPR_T expr ) ) | ID ':' TYPE ( '<-' expr )? -> ^( ATTR_T ID TYPE ( ^( EXPR_T expr ) )? ) )
            int alt7=2;
            int LA7_0 = input.LA(1);

            if ( (LA7_0==ID) ) {
                int LA7_1 = input.LA(2);

                if ( (LA7_1==49) ) {
                    alt7=1;
                }
                else if ( (LA7_1==52) ) {
                    alt7=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }
            switch (alt7) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:44:2: ID '(' ( formal ( ',' formal )* )? ')' ':' type= TYPE '{' expr '}'
                    {
                    ID9=(Token)match(input,ID,FOLLOW_ID_in_feature350); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ID.add(ID9);

                    char_literal10=(Token)match(input,49,FOLLOW_49_in_feature352); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_49.add(char_literal10);

                    // ./src/COOLTreeBuilder.g:44:9: ( formal ( ',' formal )* )?
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==ID) ) {
                        alt5=1;
                    }
                    switch (alt5) {
                        case 1 :
                            // ./src/COOLTreeBuilder.g:44:10: formal ( ',' formal )*
                            {
                            pushFollow(FOLLOW_formal_in_feature355);
                            formal11=formal();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_formal.add(formal11.getTree());
                            // ./src/COOLTreeBuilder.g:44:17: ( ',' formal )*
                            loop4:
                            do {
                                int alt4=2;
                                int LA4_0 = input.LA(1);

                                if ( (LA4_0==50) ) {
                                    alt4=1;
                                }


                                switch (alt4) {
                            	case 1 :
                            	    // ./src/COOLTreeBuilder.g:44:18: ',' formal
                            	    {
                            	    char_literal12=(Token)match(input,50,FOLLOW_50_in_feature358); if (state.failed) return retval; 
                            	    if ( state.backtracking==0 ) stream_50.add(char_literal12);

                            	    pushFollow(FOLLOW_formal_in_feature360);
                            	    formal13=formal();

                            	    state._fsp--;
                            	    if (state.failed) return retval;
                            	    if ( state.backtracking==0 ) stream_formal.add(formal13.getTree());

                            	    }
                            	    break;

                            	default :
                            	    break loop4;
                                }
                            } while (true);


                            }
                            break;

                    }

                    char_literal14=(Token)match(input,51,FOLLOW_51_in_feature366); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_51.add(char_literal14);

                    char_literal15=(Token)match(input,52,FOLLOW_52_in_feature368); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_52.add(char_literal15);

                    type=(Token)match(input,TYPE,FOLLOW_TYPE_in_feature372); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_TYPE.add(type);

                    char_literal16=(Token)match(input,47,FOLLOW_47_in_feature374); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_47.add(char_literal16);

                    pushFollow(FOLLOW_expr_in_feature376);
                    expr17=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) stream_expr.add(expr17.getTree());
                    char_literal18=(Token)match(input,48,FOLLOW_48_in_feature378); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_48.add(char_literal18);



                    // AST REWRITE
                    // elements: formal, ID, expr, TYPE
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 45:3: -> ^( METHOD_T ID TYPE ^( FORMALS_T ( formal )* ) ^( EXPR_T expr ) )
                    {
                        // ./src/COOLTreeBuilder.g:45:6: ^( METHOD_T ID TYPE ^( FORMALS_T ( formal )* ) ^( EXPR_T expr ) )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(METHOD_T, "METHOD_T"), root_1);

                        adaptor.addChild(root_1, stream_ID.nextNode());
                        adaptor.addChild(root_1, stream_TYPE.nextNode());
                        // ./src/COOLTreeBuilder.g:45:25: ^( FORMALS_T ( formal )* )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(FORMALS_T, "FORMALS_T"), root_2);

                        // ./src/COOLTreeBuilder.g:45:37: ( formal )*
                        while ( stream_formal.hasNext() ) {
                            adaptor.addChild(root_2, stream_formal.nextTree());

                        }
                        stream_formal.reset();

                        adaptor.addChild(root_1, root_2);
                        }
                        // ./src/COOLTreeBuilder.g:45:46: ^( EXPR_T expr )
                        {
                        CommonTree root_2 = (CommonTree)adaptor.nil();
                        root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPR_T, "EXPR_T"), root_2);

                        adaptor.addChild(root_2, stream_expr.nextTree());

                        adaptor.addChild(root_1, root_2);
                        }

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:47:2: ID ':' TYPE ( '<-' expr )?
                    {
                    ID19=(Token)match(input,ID,FOLLOW_ID_in_feature409); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ID.add(ID19);

                    char_literal20=(Token)match(input,52,FOLLOW_52_in_feature411); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_52.add(char_literal20);

                    TYPE21=(Token)match(input,TYPE,FOLLOW_TYPE_in_feature413); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_TYPE.add(TYPE21);

                    // ./src/COOLTreeBuilder.g:47:14: ( '<-' expr )?
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==53) ) {
                        alt6=1;
                    }
                    switch (alt6) {
                        case 1 :
                            // ./src/COOLTreeBuilder.g:47:15: '<-' expr
                            {
                            string_literal22=(Token)match(input,53,FOLLOW_53_in_feature416); if (state.failed) return retval; 
                            if ( state.backtracking==0 ) stream_53.add(string_literal22);

                            pushFollow(FOLLOW_expr_in_feature418);
                            expr23=expr();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr.add(expr23.getTree());

                            }
                            break;

                    }



                    // AST REWRITE
                    // elements: ID, TYPE, expr
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 48:3: -> ^( ATTR_T ID TYPE ( ^( EXPR_T expr ) )? )
                    {
                        // ./src/COOLTreeBuilder.g:48:6: ^( ATTR_T ID TYPE ( ^( EXPR_T expr ) )? )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(ATTR_T, "ATTR_T"), root_1);

                        adaptor.addChild(root_1, stream_ID.nextNode());
                        adaptor.addChild(root_1, stream_TYPE.nextNode());
                        // ./src/COOLTreeBuilder.g:48:23: ( ^( EXPR_T expr ) )?
                        if ( stream_expr.hasNext() ) {
                            // ./src/COOLTreeBuilder.g:48:23: ^( EXPR_T expr )
                            {
                            CommonTree root_2 = (CommonTree)adaptor.nil();
                            root_2 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(EXPR_T, "EXPR_T"), root_2);

                            adaptor.addChild(root_2, stream_expr.nextTree());

                            adaptor.addChild(root_1, root_2);
                            }

                        }
                        stream_expr.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "feature"

    public static class formal_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "formal"
    // ./src/COOLTreeBuilder.g:51:1: formal : ID ':' TYPE -> ^( TYPE_ID ID TYPE ) ;
    public final COOLTreeBuilderParser.formal_return formal() throws RecognitionException {
        COOLTreeBuilderParser.formal_return retval = new COOLTreeBuilderParser.formal_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token ID24=null;
        Token char_literal25=null;
        Token TYPE26=null;

        CommonTree ID24_tree=null;
        CommonTree char_literal25_tree=null;
        CommonTree TYPE26_tree=null;
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_52=new RewriteRuleTokenStream(adaptor,"token 52");
        RewriteRuleTokenStream stream_TYPE=new RewriteRuleTokenStream(adaptor,"token TYPE");

        try {
            // ./src/COOLTreeBuilder.g:52:2: ( ID ':' TYPE -> ^( TYPE_ID ID TYPE ) )
            // ./src/COOLTreeBuilder.g:53:2: ID ':' TYPE
            {
            ID24=(Token)match(input,ID,FOLLOW_ID_in_formal454); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_ID.add(ID24);

            char_literal25=(Token)match(input,52,FOLLOW_52_in_formal456); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_52.add(char_literal25);

            TYPE26=(Token)match(input,TYPE,FOLLOW_TYPE_in_formal458); if (state.failed) return retval; 
            if ( state.backtracking==0 ) stream_TYPE.add(TYPE26);



            // AST REWRITE
            // elements: ID, TYPE
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            // wildcard labels: 
            if ( state.backtracking==0 ) {
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 53:14: -> ^( TYPE_ID ID TYPE )
            {
                // ./src/COOLTreeBuilder.g:53:17: ^( TYPE_ID ID TYPE )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(TYPE_ID, "TYPE_ID"), root_1);

                adaptor.addChild(root_1, stream_ID.nextNode());
                adaptor.addChild(root_1, stream_TYPE.nextNode());

                adaptor.addChild(root_0, root_1);
                }

            }

            retval.tree = root_0;}
            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "formal"

    public static class expr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "expr"
    // ./src/COOLTreeBuilder.g:56:1: expr : assignExpr ;
    public final COOLTreeBuilderParser.expr_return expr() throws RecognitionException {
        COOLTreeBuilderParser.expr_return retval = new COOLTreeBuilderParser.expr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        COOLTreeBuilderParser.assignExpr_return assignExpr27 = null;



        try {
            // ./src/COOLTreeBuilder.g:57:2: ( assignExpr )
            // ./src/COOLTreeBuilder.g:58:3: assignExpr
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_assignExpr_in_expr483);
            assignExpr27=assignExpr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, assignExpr27.getTree());

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr"

    public static class assignExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "assignExpr"
    // ./src/COOLTreeBuilder.g:61:1: assignExpr : ( ID '<-' assignExpr | notExpr );
    public final COOLTreeBuilderParser.assignExpr_return assignExpr() throws RecognitionException {
        COOLTreeBuilderParser.assignExpr_return retval = new COOLTreeBuilderParser.assignExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token ID28=null;
        Token string_literal29=null;
        COOLTreeBuilderParser.assignExpr_return assignExpr30 = null;

        COOLTreeBuilderParser.notExpr_return notExpr31 = null;


        CommonTree ID28_tree=null;
        CommonTree string_literal29_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:62:3: ( ID '<-' assignExpr | notExpr )
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==ID) ) {
                int LA8_1 = input.LA(2);

                if ( (LA8_1==53) ) {
                    alt8=1;
                }
                else if ( ((LA8_1>=THEN_ST && LA8_1<=FI_ST)||(LA8_1>=LOOP_ST && LA8_1<=POOL_ST)||LA8_1==OF_ST||LA8_1==IN_ST||LA8_1==46||(LA8_1>=48 && LA8_1<=51)||(LA8_1>=54 && LA8_1<=60)||(LA8_1>=62 && LA8_1<=63)) ) {
                    alt8=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 8, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA8_0>=NOT_ST && LA8_0<=IF_ST)||LA8_0==WHILE_ST||LA8_0==CASE_ST||LA8_0==LET_ST||LA8_0==47||LA8_0==49||LA8_0==61) ) {
                alt8=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 8, 0, input);

                throw nvae;
            }
            switch (alt8) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:63:3: ID '<-' assignExpr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ID28=(Token)match(input,ID,FOLLOW_ID_in_assignExpr498); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ID28_tree = (CommonTree)adaptor.create(ID28);
                    adaptor.addChild(root_0, ID28_tree);
                    }
                    string_literal29=(Token)match(input,53,FOLLOW_53_in_assignExpr500); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    string_literal29_tree = (CommonTree)adaptor.create(string_literal29);
                    root_0 = (CommonTree)adaptor.becomeRoot(string_literal29_tree, root_0);
                    }
                    pushFollow(FOLLOW_assignExpr_in_assignExpr503);
                    assignExpr30=assignExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, assignExpr30.getTree());

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:65:3: notExpr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_notExpr_in_assignExpr511);
                    notExpr31=notExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, notExpr31.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "assignExpr"

    public static class notExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "notExpr"
    // ./src/COOLTreeBuilder.g:68:1: notExpr : ( ( NOT_ST notExpr ) | relExpr );
    public final COOLTreeBuilderParser.notExpr_return notExpr() throws RecognitionException {
        COOLTreeBuilderParser.notExpr_return retval = new COOLTreeBuilderParser.notExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NOT_ST32=null;
        COOLTreeBuilderParser.notExpr_return notExpr33 = null;

        COOLTreeBuilderParser.relExpr_return relExpr34 = null;


        CommonTree NOT_ST32_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:69:3: ( ( NOT_ST notExpr ) | relExpr )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==NOT_ST) ) {
                alt9=1;
            }
            else if ( (LA9_0==ID||(LA9_0>=ISVOID_ST && LA9_0<=IF_ST)||LA9_0==WHILE_ST||LA9_0==CASE_ST||LA9_0==LET_ST||LA9_0==47||LA9_0==49||LA9_0==61) ) {
                alt9=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:70:3: ( NOT_ST notExpr )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    // ./src/COOLTreeBuilder.g:70:3: ( NOT_ST notExpr )
                    // ./src/COOLTreeBuilder.g:70:4: NOT_ST notExpr
                    {
                    NOT_ST32=(Token)match(input,NOT_ST,FOLLOW_NOT_ST_in_notExpr527); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    NOT_ST32_tree = (CommonTree)adaptor.create(NOT_ST32);
                    root_0 = (CommonTree)adaptor.becomeRoot(NOT_ST32_tree, root_0);
                    }
                    pushFollow(FOLLOW_notExpr_in_notExpr530);
                    notExpr33=notExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, notExpr33.getTree());

                    }


                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:72:3: relExpr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_relExpr_in_notExpr539);
                    relExpr34=relExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, relExpr34.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "notExpr"

    public static class relExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "relExpr"
    // ./src/COOLTreeBuilder.g:75:1: relExpr : sumExpr ( ( '<=' )=> '<=' sumExpr | ( '<' )=> '<' sumExpr | ( '=' )=> '=' sumExpr )* ;
    public final COOLTreeBuilderParser.relExpr_return relExpr() throws RecognitionException {
        COOLTreeBuilderParser.relExpr_return retval = new COOLTreeBuilderParser.relExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token string_literal36=null;
        Token char_literal38=null;
        Token char_literal40=null;
        COOLTreeBuilderParser.sumExpr_return sumExpr35 = null;

        COOLTreeBuilderParser.sumExpr_return sumExpr37 = null;

        COOLTreeBuilderParser.sumExpr_return sumExpr39 = null;

        COOLTreeBuilderParser.sumExpr_return sumExpr41 = null;


        CommonTree string_literal36_tree=null;
        CommonTree char_literal38_tree=null;
        CommonTree char_literal40_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:76:3: ( sumExpr ( ( '<=' )=> '<=' sumExpr | ( '<' )=> '<' sumExpr | ( '=' )=> '=' sumExpr )* )
            // ./src/COOLTreeBuilder.g:77:3: sumExpr ( ( '<=' )=> '<=' sumExpr | ( '<' )=> '<' sumExpr | ( '=' )=> '=' sumExpr )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_sumExpr_in_relExpr554);
            sumExpr35=sumExpr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, sumExpr35.getTree());
            // ./src/COOLTreeBuilder.g:78:3: ( ( '<=' )=> '<=' sumExpr | ( '<' )=> '<' sumExpr | ( '=' )=> '=' sumExpr )*
            loop10:
            do {
                int alt10=4;
                switch ( input.LA(1) ) {
                case 54:
                    {
                    int LA10_2 = input.LA(2);

                    if ( (synpred1_COOLTreeBuilder()) ) {
                        alt10=1;
                    }


                    }
                    break;
                case 55:
                    {
                    int LA10_3 = input.LA(2);

                    if ( (synpred2_COOLTreeBuilder()) ) {
                        alt10=2;
                    }


                    }
                    break;
                case 56:
                    {
                    int LA10_4 = input.LA(2);

                    if ( (synpred3_COOLTreeBuilder()) ) {
                        alt10=3;
                    }


                    }
                    break;

                }

                switch (alt10) {
            	case 1 :
            	    // ./src/COOLTreeBuilder.g:79:5: ( '<=' )=> '<=' sumExpr
            	    {
            	    string_literal36=(Token)match(input,54,FOLLOW_54_in_relExpr570); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    string_literal36_tree = (CommonTree)adaptor.create(string_literal36);
            	    root_0 = (CommonTree)adaptor.becomeRoot(string_literal36_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_sumExpr_in_relExpr573);
            	    sumExpr37=sumExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, sumExpr37.getTree());

            	    }
            	    break;
            	case 2 :
            	    // ./src/COOLTreeBuilder.g:81:5: ( '<' )=> '<' sumExpr
            	    {
            	    char_literal38=(Token)match(input,55,FOLLOW_55_in_relExpr591); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal38_tree = (CommonTree)adaptor.create(char_literal38);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal38_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_sumExpr_in_relExpr594);
            	    sumExpr39=sumExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, sumExpr39.getTree());

            	    }
            	    break;
            	case 3 :
            	    // ./src/COOLTreeBuilder.g:83:5: ( '=' )=> '=' sumExpr
            	    {
            	    char_literal40=(Token)match(input,56,FOLLOW_56_in_relExpr612); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal40_tree = (CommonTree)adaptor.create(char_literal40);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal40_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_sumExpr_in_relExpr615);
            	    sumExpr41=sumExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, sumExpr41.getTree());

            	    }
            	    break;

            	default :
            	    break loop10;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "relExpr"

    public static class sumExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "sumExpr"
    // ./src/COOLTreeBuilder.g:87:1: sumExpr : multExpr ( ( '+' )=> '+' multExpr | ( '-' )=> '-' multExpr )* ;
    public final COOLTreeBuilderParser.sumExpr_return sumExpr() throws RecognitionException {
        COOLTreeBuilderParser.sumExpr_return retval = new COOLTreeBuilderParser.sumExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal43=null;
        Token char_literal45=null;
        COOLTreeBuilderParser.multExpr_return multExpr42 = null;

        COOLTreeBuilderParser.multExpr_return multExpr44 = null;

        COOLTreeBuilderParser.multExpr_return multExpr46 = null;


        CommonTree char_literal43_tree=null;
        CommonTree char_literal45_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:88:3: ( multExpr ( ( '+' )=> '+' multExpr | ( '-' )=> '-' multExpr )* )
            // ./src/COOLTreeBuilder.g:89:3: multExpr ( ( '+' )=> '+' multExpr | ( '-' )=> '-' multExpr )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_multExpr_in_sumExpr635);
            multExpr42=multExpr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, multExpr42.getTree());
            // ./src/COOLTreeBuilder.g:90:3: ( ( '+' )=> '+' multExpr | ( '-' )=> '-' multExpr )*
            loop11:
            do {
                int alt11=3;
                int LA11_0 = input.LA(1);

                if ( (LA11_0==57) ) {
                    int LA11_2 = input.LA(2);

                    if ( (synpred4_COOLTreeBuilder()) ) {
                        alt11=1;
                    }


                }
                else if ( (LA11_0==58) ) {
                    int LA11_3 = input.LA(2);

                    if ( (synpred5_COOLTreeBuilder()) ) {
                        alt11=2;
                    }


                }


                switch (alt11) {
            	case 1 :
            	    // ./src/COOLTreeBuilder.g:91:5: ( '+' )=> '+' multExpr
            	    {
            	    char_literal43=(Token)match(input,57,FOLLOW_57_in_sumExpr651); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal43_tree = (CommonTree)adaptor.create(char_literal43);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal43_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_multExpr_in_sumExpr654);
            	    multExpr44=multExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, multExpr44.getTree());

            	    }
            	    break;
            	case 2 :
            	    // ./src/COOLTreeBuilder.g:93:5: ( '-' )=> '-' multExpr
            	    {
            	    char_literal45=(Token)match(input,58,FOLLOW_58_in_sumExpr672); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal45_tree = (CommonTree)adaptor.create(char_literal45);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal45_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_multExpr_in_sumExpr675);
            	    multExpr46=multExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, multExpr46.getTree());

            	    }
            	    break;

            	default :
            	    break loop11;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "sumExpr"

    public static class multExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "multExpr"
    // ./src/COOLTreeBuilder.g:97:1: multExpr : isVoidExpr ( ( '*' )=> '*' isVoidExpr | ( '/' )=> ( '/' isVoidExpr ) )* ;
    public final COOLTreeBuilderParser.multExpr_return multExpr() throws RecognitionException {
        COOLTreeBuilderParser.multExpr_return retval = new COOLTreeBuilderParser.multExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal48=null;
        Token char_literal50=null;
        COOLTreeBuilderParser.isVoidExpr_return isVoidExpr47 = null;

        COOLTreeBuilderParser.isVoidExpr_return isVoidExpr49 = null;

        COOLTreeBuilderParser.isVoidExpr_return isVoidExpr51 = null;


        CommonTree char_literal48_tree=null;
        CommonTree char_literal50_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:98:3: ( isVoidExpr ( ( '*' )=> '*' isVoidExpr | ( '/' )=> ( '/' isVoidExpr ) )* )
            // ./src/COOLTreeBuilder.g:99:3: isVoidExpr ( ( '*' )=> '*' isVoidExpr | ( '/' )=> ( '/' isVoidExpr ) )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_isVoidExpr_in_multExpr695);
            isVoidExpr47=isVoidExpr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, isVoidExpr47.getTree());
            // ./src/COOLTreeBuilder.g:100:3: ( ( '*' )=> '*' isVoidExpr | ( '/' )=> ( '/' isVoidExpr ) )*
            loop12:
            do {
                int alt12=3;
                int LA12_0 = input.LA(1);

                if ( (LA12_0==59) ) {
                    int LA12_2 = input.LA(2);

                    if ( (synpred6_COOLTreeBuilder()) ) {
                        alt12=1;
                    }


                }
                else if ( (LA12_0==60) ) {
                    int LA12_3 = input.LA(2);

                    if ( (synpred7_COOLTreeBuilder()) ) {
                        alt12=2;
                    }


                }


                switch (alt12) {
            	case 1 :
            	    // ./src/COOLTreeBuilder.g:101:5: ( '*' )=> '*' isVoidExpr
            	    {
            	    char_literal48=(Token)match(input,59,FOLLOW_59_in_multExpr711); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal48_tree = (CommonTree)adaptor.create(char_literal48);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal48_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_isVoidExpr_in_multExpr714);
            	    isVoidExpr49=isVoidExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, isVoidExpr49.getTree());

            	    }
            	    break;
            	case 2 :
            	    // ./src/COOLTreeBuilder.g:103:5: ( '/' )=> ( '/' isVoidExpr )
            	    {
            	    // ./src/COOLTreeBuilder.g:103:14: ( '/' isVoidExpr )
            	    // ./src/COOLTreeBuilder.g:103:15: '/' isVoidExpr
            	    {
            	    char_literal50=(Token)match(input,60,FOLLOW_60_in_multExpr733); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal50_tree = (CommonTree)adaptor.create(char_literal50);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal50_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_isVoidExpr_in_multExpr736);
            	    isVoidExpr51=isVoidExpr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, isVoidExpr51.getTree());

            	    }


            	    }
            	    break;

            	default :
            	    break loop12;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "multExpr"

    public static class isVoidExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "isVoidExpr"
    // ./src/COOLTreeBuilder.g:107:1: isVoidExpr : ( ( ISVOID_ST isVoidExpr ) | tildaExpr );
    public final COOLTreeBuilderParser.isVoidExpr_return isVoidExpr() throws RecognitionException {
        COOLTreeBuilderParser.isVoidExpr_return retval = new COOLTreeBuilderParser.isVoidExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token ISVOID_ST52=null;
        COOLTreeBuilderParser.isVoidExpr_return isVoidExpr53 = null;

        COOLTreeBuilderParser.tildaExpr_return tildaExpr54 = null;


        CommonTree ISVOID_ST52_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:108:3: ( ( ISVOID_ST isVoidExpr ) | tildaExpr )
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==ISVOID_ST) ) {
                alt13=1;
            }
            else if ( (LA13_0==ID||(LA13_0>=INTEGER && LA13_0<=IF_ST)||LA13_0==WHILE_ST||LA13_0==CASE_ST||LA13_0==LET_ST||LA13_0==47||LA13_0==49||LA13_0==61) ) {
                alt13=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 13, 0, input);

                throw nvae;
            }
            switch (alt13) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:109:3: ( ISVOID_ST isVoidExpr )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    // ./src/COOLTreeBuilder.g:109:3: ( ISVOID_ST isVoidExpr )
                    // ./src/COOLTreeBuilder.g:109:4: ISVOID_ST isVoidExpr
                    {
                    ISVOID_ST52=(Token)match(input,ISVOID_ST,FOLLOW_ISVOID_ST_in_isVoidExpr758); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ISVOID_ST52_tree = (CommonTree)adaptor.create(ISVOID_ST52);
                    root_0 = (CommonTree)adaptor.becomeRoot(ISVOID_ST52_tree, root_0);
                    }
                    pushFollow(FOLLOW_isVoidExpr_in_isVoidExpr761);
                    isVoidExpr53=isVoidExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, isVoidExpr53.getTree());

                    }


                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:111:3: tildaExpr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_tildaExpr_in_isVoidExpr770);
                    tildaExpr54=tildaExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, tildaExpr54.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "isVoidExpr"

    public static class tildaExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "tildaExpr"
    // ./src/COOLTreeBuilder.g:114:1: tildaExpr : ( ( '~' tildaExpr ) | dispatchExpr );
    public final COOLTreeBuilderParser.tildaExpr_return tildaExpr() throws RecognitionException {
        COOLTreeBuilderParser.tildaExpr_return retval = new COOLTreeBuilderParser.tildaExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal55=null;
        COOLTreeBuilderParser.tildaExpr_return tildaExpr56 = null;

        COOLTreeBuilderParser.dispatchExpr_return dispatchExpr57 = null;


        CommonTree char_literal55_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:115:3: ( ( '~' tildaExpr ) | dispatchExpr )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==61) ) {
                alt14=1;
            }
            else if ( (LA14_0==ID||(LA14_0>=INTEGER && LA14_0<=IF_ST)||LA14_0==WHILE_ST||LA14_0==CASE_ST||LA14_0==LET_ST||LA14_0==47||LA14_0==49) ) {
                alt14=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:116:3: ( '~' tildaExpr )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    // ./src/COOLTreeBuilder.g:116:3: ( '~' tildaExpr )
                    // ./src/COOLTreeBuilder.g:116:4: '~' tildaExpr
                    {
                    char_literal55=(Token)match(input,61,FOLLOW_61_in_tildaExpr786); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    char_literal55_tree = (CommonTree)adaptor.create(char_literal55);
                    root_0 = (CommonTree)adaptor.becomeRoot(char_literal55_tree, root_0);
                    }
                    pushFollow(FOLLOW_tildaExpr_in_tildaExpr789);
                    tildaExpr56=tildaExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, tildaExpr56.getTree());

                    }


                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:118:3: dispatchExpr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_dispatchExpr_in_tildaExpr798);
                    dispatchExpr57=dispatchExpr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, dispatchExpr57.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "tildaExpr"

    public static class dispatchExpr_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dispatchExpr"
    // ./src/COOLTreeBuilder.g:121:1: dispatchExpr : atom ( ( '@' )=> '@' TYPE | ) ( ( '.' dispatchExprAux )=> '.' dispatchExprAux )* ;
    public final COOLTreeBuilderParser.dispatchExpr_return dispatchExpr() throws RecognitionException {
        COOLTreeBuilderParser.dispatchExpr_return retval = new COOLTreeBuilderParser.dispatchExpr_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token char_literal59=null;
        Token TYPE60=null;
        Token char_literal61=null;
        COOLTreeBuilderParser.atom_return atom58 = null;

        COOLTreeBuilderParser.dispatchExprAux_return dispatchExprAux62 = null;


        CommonTree char_literal59_tree=null;
        CommonTree TYPE60_tree=null;
        CommonTree char_literal61_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:122:3: ( atom ( ( '@' )=> '@' TYPE | ) ( ( '.' dispatchExprAux )=> '.' dispatchExprAux )* )
            // ./src/COOLTreeBuilder.g:123:4: atom ( ( '@' )=> '@' TYPE | ) ( ( '.' dispatchExprAux )=> '.' dispatchExprAux )*
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_atom_in_dispatchExpr814);
            atom58=atom();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) adaptor.addChild(root_0, atom58.getTree());
            // ./src/COOLTreeBuilder.g:123:9: ( ( '@' )=> '@' TYPE | )
            int alt15=2;
            int LA15_0 = input.LA(1);

            if ( (LA15_0==62) ) {
                int LA15_1 = input.LA(2);

                if ( (synpred8_COOLTreeBuilder()) ) {
                    alt15=1;
                }
                else if ( (true) ) {
                    alt15=2;
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return retval;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 15, 1, input);

                    throw nvae;
                }
            }
            else if ( ((LA15_0>=THEN_ST && LA15_0<=FI_ST)||(LA15_0>=LOOP_ST && LA15_0<=POOL_ST)||LA15_0==OF_ST||LA15_0==IN_ST||LA15_0==46||LA15_0==48||(LA15_0>=50 && LA15_0<=51)||(LA15_0>=54 && LA15_0<=60)||LA15_0==63) ) {
                alt15=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 15, 0, input);

                throw nvae;
            }
            switch (alt15) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:124:5: ( '@' )=> '@' TYPE
                    {
                    char_literal59=(Token)match(input,62,FOLLOW_62_in_dispatchExpr828); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    char_literal59_tree = (CommonTree)adaptor.create(char_literal59);
                    root_0 = (CommonTree)adaptor.becomeRoot(char_literal59_tree, root_0);
                    }
                    TYPE60=(Token)match(input,TYPE,FOLLOW_TYPE_in_dispatchExpr831); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    TYPE60_tree = (CommonTree)adaptor.create(TYPE60);
                    adaptor.addChild(root_0, TYPE60_tree);
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:126:3: 
                    {
                    }
                    break;

            }

            // ./src/COOLTreeBuilder.g:127:3: ( ( '.' dispatchExprAux )=> '.' dispatchExprAux )*
            loop16:
            do {
                int alt16=2;
                int LA16_0 = input.LA(1);

                if ( (LA16_0==63) ) {
                    int LA16_2 = input.LA(2);

                    if ( (synpred9_COOLTreeBuilder()) ) {
                        alt16=1;
                    }


                }


                switch (alt16) {
            	case 1 :
            	    // ./src/COOLTreeBuilder.g:127:4: ( '.' dispatchExprAux )=> '.' dispatchExprAux
            	    {
            	    char_literal61=(Token)match(input,63,FOLLOW_63_in_dispatchExpr854); if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {
            	    char_literal61_tree = (CommonTree)adaptor.create(char_literal61);
            	    root_0 = (CommonTree)adaptor.becomeRoot(char_literal61_tree, root_0);
            	    }
            	    pushFollow(FOLLOW_dispatchExprAux_in_dispatchExpr857);
            	    dispatchExprAux62=dispatchExprAux();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) adaptor.addChild(root_0, dispatchExprAux62.getTree());

            	    }
            	    break;

            	default :
            	    break loop16;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dispatchExpr"

    public static class dispatchExprAux_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "dispatchExprAux"
    // ./src/COOLTreeBuilder.g:130:1: dispatchExprAux : ID '(' ( expr ( ',' expr )* )? ')' ;
    public final COOLTreeBuilderParser.dispatchExprAux_return dispatchExprAux() throws RecognitionException {
        COOLTreeBuilderParser.dispatchExprAux_return retval = new COOLTreeBuilderParser.dispatchExprAux_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token ID63=null;
        Token char_literal64=null;
        Token char_literal66=null;
        Token char_literal68=null;
        COOLTreeBuilderParser.expr_return expr65 = null;

        COOLTreeBuilderParser.expr_return expr67 = null;


        CommonTree ID63_tree=null;
        CommonTree char_literal64_tree=null;
        CommonTree char_literal66_tree=null;
        CommonTree char_literal68_tree=null;

        try {
            // ./src/COOLTreeBuilder.g:131:3: ( ID '(' ( expr ( ',' expr )* )? ')' )
            // ./src/COOLTreeBuilder.g:132:3: ID '(' ( expr ( ',' expr )* )? ')'
            {
            root_0 = (CommonTree)adaptor.nil();

            ID63=(Token)match(input,ID,FOLLOW_ID_in_dispatchExprAux874); if (state.failed) return retval;
            if ( state.backtracking==0 ) {
            ID63_tree = (CommonTree)adaptor.create(ID63);
            adaptor.addChild(root_0, ID63_tree);
            }
            char_literal64=(Token)match(input,49,FOLLOW_49_in_dispatchExprAux876); if (state.failed) return retval;
            // ./src/COOLTreeBuilder.g:132:11: ( expr ( ',' expr )* )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( ((LA18_0>=ID && LA18_0<=IF_ST)||LA18_0==WHILE_ST||LA18_0==CASE_ST||LA18_0==LET_ST||LA18_0==47||LA18_0==49||LA18_0==61) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:132:12: expr ( ',' expr )*
                    {
                    pushFollow(FOLLOW_expr_in_dispatchExprAux880);
                    expr65=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr65.getTree());
                    // ./src/COOLTreeBuilder.g:132:17: ( ',' expr )*
                    loop17:
                    do {
                        int alt17=2;
                        int LA17_0 = input.LA(1);

                        if ( (LA17_0==50) ) {
                            alt17=1;
                        }


                        switch (alt17) {
                    	case 1 :
                    	    // ./src/COOLTreeBuilder.g:132:18: ',' expr
                    	    {
                    	    char_literal66=(Token)match(input,50,FOLLOW_50_in_dispatchExprAux883); if (state.failed) return retval;
                    	    pushFollow(FOLLOW_expr_in_dispatchExprAux886);
                    	    expr67=expr();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr67.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop17;
                        }
                    } while (true);


                    }
                    break;

            }

            char_literal68=(Token)match(input,51,FOLLOW_51_in_dispatchExprAux892); if (state.failed) return retval;

            }

            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "dispatchExprAux"

    public static class atom_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start "atom"
    // ./src/COOLTreeBuilder.g:135:1: atom : ( INTEGER | ID | '(' expr ')' | TRUE_ST | FALSE_ST | STRING | ID '(' ( expr ( ',' expr )* )? ')' -> ^( CALL_T ID ( expr )* ) | '{' ( expr ';' )+ '}' | NEW_ST TYPE | IF_ST expr THEN_ST expr ELSE_ST expr FI_ST | WHILE_ST expr LOOP_ST expr POOL_ST | CASE_ST expr OF_ST ( ID ':' TYPE '=>' expr ';' )+ ESAC_ST | LET_ST ID ':' TYPE ( '<-' expr )? ( ',' ID ':' TYPE ( '<-' expr )? )* IN_ST expr );
    public final COOLTreeBuilderParser.atom_return atom() throws RecognitionException {
        COOLTreeBuilderParser.atom_return retval = new COOLTreeBuilderParser.atom_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token INTEGER69=null;
        Token ID70=null;
        Token char_literal71=null;
        Token char_literal73=null;
        Token TRUE_ST74=null;
        Token FALSE_ST75=null;
        Token STRING76=null;
        Token ID77=null;
        Token char_literal78=null;
        Token char_literal80=null;
        Token char_literal82=null;
        Token char_literal83=null;
        Token char_literal85=null;
        Token char_literal86=null;
        Token NEW_ST87=null;
        Token TYPE88=null;
        Token IF_ST89=null;
        Token THEN_ST91=null;
        Token ELSE_ST93=null;
        Token FI_ST95=null;
        Token WHILE_ST96=null;
        Token LOOP_ST98=null;
        Token POOL_ST100=null;
        Token CASE_ST101=null;
        Token OF_ST103=null;
        Token ID104=null;
        Token char_literal105=null;
        Token TYPE106=null;
        Token string_literal107=null;
        Token char_literal109=null;
        Token ESAC_ST110=null;
        Token LET_ST111=null;
        Token ID112=null;
        Token char_literal113=null;
        Token TYPE114=null;
        Token string_literal115=null;
        Token char_literal117=null;
        Token ID118=null;
        Token char_literal119=null;
        Token TYPE120=null;
        Token string_literal121=null;
        Token IN_ST123=null;
        COOLTreeBuilderParser.expr_return expr72 = null;

        COOLTreeBuilderParser.expr_return expr79 = null;

        COOLTreeBuilderParser.expr_return expr81 = null;

        COOLTreeBuilderParser.expr_return expr84 = null;

        COOLTreeBuilderParser.expr_return expr90 = null;

        COOLTreeBuilderParser.expr_return expr92 = null;

        COOLTreeBuilderParser.expr_return expr94 = null;

        COOLTreeBuilderParser.expr_return expr97 = null;

        COOLTreeBuilderParser.expr_return expr99 = null;

        COOLTreeBuilderParser.expr_return expr102 = null;

        COOLTreeBuilderParser.expr_return expr108 = null;

        COOLTreeBuilderParser.expr_return expr116 = null;

        COOLTreeBuilderParser.expr_return expr122 = null;

        COOLTreeBuilderParser.expr_return expr124 = null;


        CommonTree INTEGER69_tree=null;
        CommonTree ID70_tree=null;
        CommonTree char_literal71_tree=null;
        CommonTree char_literal73_tree=null;
        CommonTree TRUE_ST74_tree=null;
        CommonTree FALSE_ST75_tree=null;
        CommonTree STRING76_tree=null;
        CommonTree ID77_tree=null;
        CommonTree char_literal78_tree=null;
        CommonTree char_literal80_tree=null;
        CommonTree char_literal82_tree=null;
        CommonTree char_literal83_tree=null;
        CommonTree char_literal85_tree=null;
        CommonTree char_literal86_tree=null;
        CommonTree NEW_ST87_tree=null;
        CommonTree TYPE88_tree=null;
        CommonTree IF_ST89_tree=null;
        CommonTree THEN_ST91_tree=null;
        CommonTree ELSE_ST93_tree=null;
        CommonTree FI_ST95_tree=null;
        CommonTree WHILE_ST96_tree=null;
        CommonTree LOOP_ST98_tree=null;
        CommonTree POOL_ST100_tree=null;
        CommonTree CASE_ST101_tree=null;
        CommonTree OF_ST103_tree=null;
        CommonTree ID104_tree=null;
        CommonTree char_literal105_tree=null;
        CommonTree TYPE106_tree=null;
        CommonTree string_literal107_tree=null;
        CommonTree char_literal109_tree=null;
        CommonTree ESAC_ST110_tree=null;
        CommonTree LET_ST111_tree=null;
        CommonTree ID112_tree=null;
        CommonTree char_literal113_tree=null;
        CommonTree TYPE114_tree=null;
        CommonTree string_literal115_tree=null;
        CommonTree char_literal117_tree=null;
        CommonTree ID118_tree=null;
        CommonTree char_literal119_tree=null;
        CommonTree TYPE120_tree=null;
        CommonTree string_literal121_tree=null;
        CommonTree IN_ST123_tree=null;
        RewriteRuleTokenStream stream_49=new RewriteRuleTokenStream(adaptor,"token 49");
        RewriteRuleTokenStream stream_51=new RewriteRuleTokenStream(adaptor,"token 51");
        RewriteRuleTokenStream stream_ID=new RewriteRuleTokenStream(adaptor,"token ID");
        RewriteRuleTokenStream stream_50=new RewriteRuleTokenStream(adaptor,"token 50");
        RewriteRuleSubtreeStream stream_expr=new RewriteRuleSubtreeStream(adaptor,"rule expr");
        try {
            // ./src/COOLTreeBuilder.g:136:3: ( INTEGER | ID | '(' expr ')' | TRUE_ST | FALSE_ST | STRING | ID '(' ( expr ( ',' expr )* )? ')' -> ^( CALL_T ID ( expr )* ) | '{' ( expr ';' )+ '}' | NEW_ST TYPE | IF_ST expr THEN_ST expr ELSE_ST expr FI_ST | WHILE_ST expr LOOP_ST expr POOL_ST | CASE_ST expr OF_ST ( ID ':' TYPE '=>' expr ';' )+ ESAC_ST | LET_ST ID ':' TYPE ( '<-' expr )? ( ',' ID ':' TYPE ( '<-' expr )? )* IN_ST expr )
            int alt26=13;
            alt26 = dfa26.predict(input);
            switch (alt26) {
                case 1 :
                    // ./src/COOLTreeBuilder.g:136:7: INTEGER
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    INTEGER69=(Token)match(input,INTEGER,FOLLOW_INTEGER_in_atom908); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    INTEGER69_tree = (CommonTree)adaptor.create(INTEGER69);
                    adaptor.addChild(root_0, INTEGER69_tree);
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeBuilder.g:137:7: ID
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    ID70=(Token)match(input,ID,FOLLOW_ID_in_atom916); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ID70_tree = (CommonTree)adaptor.create(ID70);
                    adaptor.addChild(root_0, ID70_tree);
                    }

                    }
                    break;
                case 3 :
                    // ./src/COOLTreeBuilder.g:138:7: '(' expr ')'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    char_literal71=(Token)match(input,49,FOLLOW_49_in_atom924); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_atom927);
                    expr72=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr72.getTree());
                    char_literal73=(Token)match(input,51,FOLLOW_51_in_atom929); if (state.failed) return retval;

                    }
                    break;
                case 4 :
                    // ./src/COOLTreeBuilder.g:139:7: TRUE_ST
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    TRUE_ST74=(Token)match(input,TRUE_ST,FOLLOW_TRUE_ST_in_atom938); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    TRUE_ST74_tree = (CommonTree)adaptor.create(TRUE_ST74);
                    adaptor.addChild(root_0, TRUE_ST74_tree);
                    }

                    }
                    break;
                case 5 :
                    // ./src/COOLTreeBuilder.g:140:7: FALSE_ST
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    FALSE_ST75=(Token)match(input,FALSE_ST,FOLLOW_FALSE_ST_in_atom946); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    FALSE_ST75_tree = (CommonTree)adaptor.create(FALSE_ST75);
                    adaptor.addChild(root_0, FALSE_ST75_tree);
                    }

                    }
                    break;
                case 6 :
                    // ./src/COOLTreeBuilder.g:141:7: STRING
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    STRING76=(Token)match(input,STRING,FOLLOW_STRING_in_atom954); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    STRING76_tree = (CommonTree)adaptor.create(STRING76);
                    adaptor.addChild(root_0, STRING76_tree);
                    }

                    }
                    break;
                case 7 :
                    // ./src/COOLTreeBuilder.g:142:7: ID '(' ( expr ( ',' expr )* )? ')'
                    {
                    ID77=(Token)match(input,ID,FOLLOW_ID_in_atom962); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_ID.add(ID77);

                    char_literal78=(Token)match(input,49,FOLLOW_49_in_atom964); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_49.add(char_literal78);

                    // ./src/COOLTreeBuilder.g:142:14: ( expr ( ',' expr )* )?
                    int alt20=2;
                    int LA20_0 = input.LA(1);

                    if ( ((LA20_0>=ID && LA20_0<=IF_ST)||LA20_0==WHILE_ST||LA20_0==CASE_ST||LA20_0==LET_ST||LA20_0==47||LA20_0==49||LA20_0==61) ) {
                        alt20=1;
                    }
                    switch (alt20) {
                        case 1 :
                            // ./src/COOLTreeBuilder.g:142:15: expr ( ',' expr )*
                            {
                            pushFollow(FOLLOW_expr_in_atom967);
                            expr79=expr();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) stream_expr.add(expr79.getTree());
                            // ./src/COOLTreeBuilder.g:142:20: ( ',' expr )*
                            loop19:
                            do {
                                int alt19=2;
                                int LA19_0 = input.LA(1);

                                if ( (LA19_0==50) ) {
                                    alt19=1;
                                }


                                switch (alt19) {
                            	case 1 :
                            	    // ./src/COOLTreeBuilder.g:142:21: ',' expr
                            	    {
                            	    char_literal80=(Token)match(input,50,FOLLOW_50_in_atom970); if (state.failed) return retval; 
                            	    if ( state.backtracking==0 ) stream_50.add(char_literal80);

                            	    pushFollow(FOLLOW_expr_in_atom972);
                            	    expr81=expr();

                            	    state._fsp--;
                            	    if (state.failed) return retval;
                            	    if ( state.backtracking==0 ) stream_expr.add(expr81.getTree());

                            	    }
                            	    break;

                            	default :
                            	    break loop19;
                                }
                            } while (true);


                            }
                            break;

                    }

                    char_literal82=(Token)match(input,51,FOLLOW_51_in_atom978); if (state.failed) return retval; 
                    if ( state.backtracking==0 ) stream_51.add(char_literal82);



                    // AST REWRITE
                    // elements: expr, ID
                    // token labels: 
                    // rule labels: retval
                    // token list labels: 
                    // rule list labels: 
                    // wildcard labels: 
                    if ( state.backtracking==0 ) {
                    retval.tree = root_0;
                    RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"rule retval",retval!=null?retval.tree:null);

                    root_0 = (CommonTree)adaptor.nil();
                    // 142:38: -> ^( CALL_T ID ( expr )* )
                    {
                        // ./src/COOLTreeBuilder.g:142:41: ^( CALL_T ID ( expr )* )
                        {
                        CommonTree root_1 = (CommonTree)adaptor.nil();
                        root_1 = (CommonTree)adaptor.becomeRoot((CommonTree)adaptor.create(CALL_T, "CALL_T"), root_1);

                        adaptor.addChild(root_1, stream_ID.nextNode());
                        // ./src/COOLTreeBuilder.g:142:53: ( expr )*
                        while ( stream_expr.hasNext() ) {
                            adaptor.addChild(root_1, stream_expr.nextTree());

                        }
                        stream_expr.reset();

                        adaptor.addChild(root_0, root_1);
                        }

                    }

                    retval.tree = root_0;}
                    }
                    break;
                case 8 :
                    // ./src/COOLTreeBuilder.g:143:6: '{' ( expr ';' )+ '}'
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    char_literal83=(Token)match(input,47,FOLLOW_47_in_atom996); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    char_literal83_tree = (CommonTree)adaptor.create(char_literal83);
                    root_0 = (CommonTree)adaptor.becomeRoot(char_literal83_tree, root_0);
                    }
                    // ./src/COOLTreeBuilder.g:143:11: ( expr ';' )+
                    int cnt21=0;
                    loop21:
                    do {
                        int alt21=2;
                        int LA21_0 = input.LA(1);

                        if ( ((LA21_0>=ID && LA21_0<=IF_ST)||LA21_0==WHILE_ST||LA21_0==CASE_ST||LA21_0==LET_ST||LA21_0==47||LA21_0==49||LA21_0==61) ) {
                            alt21=1;
                        }


                        switch (alt21) {
                    	case 1 :
                    	    // ./src/COOLTreeBuilder.g:143:12: expr ';'
                    	    {
                    	    pushFollow(FOLLOW_expr_in_atom1000);
                    	    expr84=expr();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr84.getTree());
                    	    char_literal85=(Token)match(input,46,FOLLOW_46_in_atom1002); if (state.failed) return retval;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt21 >= 1 ) break loop21;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(21, input);
                                throw eee;
                        }
                        cnt21++;
                    } while (true);

                    char_literal86=(Token)match(input,48,FOLLOW_48_in_atom1007); if (state.failed) return retval;

                    }
                    break;
                case 9 :
                    // ./src/COOLTreeBuilder.g:144:7: NEW_ST TYPE
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    NEW_ST87=(Token)match(input,NEW_ST,FOLLOW_NEW_ST_in_atom1016); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    NEW_ST87_tree = (CommonTree)adaptor.create(NEW_ST87);
                    root_0 = (CommonTree)adaptor.becomeRoot(NEW_ST87_tree, root_0);
                    }
                    TYPE88=(Token)match(input,TYPE,FOLLOW_TYPE_in_atom1019); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    TYPE88_tree = (CommonTree)adaptor.create(TYPE88);
                    adaptor.addChild(root_0, TYPE88_tree);
                    }

                    }
                    break;
                case 10 :
                    // ./src/COOLTreeBuilder.g:145:7: IF_ST expr THEN_ST expr ELSE_ST expr FI_ST
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    IF_ST89=(Token)match(input,IF_ST,FOLLOW_IF_ST_in_atom1027); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    IF_ST89_tree = (CommonTree)adaptor.create(IF_ST89);
                    root_0 = (CommonTree)adaptor.becomeRoot(IF_ST89_tree, root_0);
                    }
                    pushFollow(FOLLOW_expr_in_atom1030);
                    expr90=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr90.getTree());
                    THEN_ST91=(Token)match(input,THEN_ST,FOLLOW_THEN_ST_in_atom1032); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_atom1035);
                    expr92=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr92.getTree());
                    ELSE_ST93=(Token)match(input,ELSE_ST,FOLLOW_ELSE_ST_in_atom1037); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_atom1040);
                    expr94=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr94.getTree());
                    FI_ST95=(Token)match(input,FI_ST,FOLLOW_FI_ST_in_atom1042); if (state.failed) return retval;

                    }
                    break;
                case 11 :
                    // ./src/COOLTreeBuilder.g:146:7: WHILE_ST expr LOOP_ST expr POOL_ST
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    WHILE_ST96=(Token)match(input,WHILE_ST,FOLLOW_WHILE_ST_in_atom1052); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    WHILE_ST96_tree = (CommonTree)adaptor.create(WHILE_ST96);
                    root_0 = (CommonTree)adaptor.becomeRoot(WHILE_ST96_tree, root_0);
                    }
                    pushFollow(FOLLOW_expr_in_atom1055);
                    expr97=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr97.getTree());
                    LOOP_ST98=(Token)match(input,LOOP_ST,FOLLOW_LOOP_ST_in_atom1057); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_atom1060);
                    expr99=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr99.getTree());
                    POOL_ST100=(Token)match(input,POOL_ST,FOLLOW_POOL_ST_in_atom1062); if (state.failed) return retval;

                    }
                    break;
                case 12 :
                    // ./src/COOLTreeBuilder.g:147:7: CASE_ST expr OF_ST ( ID ':' TYPE '=>' expr ';' )+ ESAC_ST
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    CASE_ST101=(Token)match(input,CASE_ST,FOLLOW_CASE_ST_in_atom1072); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    CASE_ST101_tree = (CommonTree)adaptor.create(CASE_ST101);
                    root_0 = (CommonTree)adaptor.becomeRoot(CASE_ST101_tree, root_0);
                    }
                    pushFollow(FOLLOW_expr_in_atom1075);
                    expr102=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr102.getTree());
                    OF_ST103=(Token)match(input,OF_ST,FOLLOW_OF_ST_in_atom1077); if (state.failed) return retval;
                    // ./src/COOLTreeBuilder.g:147:28: ( ID ':' TYPE '=>' expr ';' )+
                    int cnt22=0;
                    loop22:
                    do {
                        int alt22=2;
                        int LA22_0 = input.LA(1);

                        if ( (LA22_0==ID) ) {
                            alt22=1;
                        }


                        switch (alt22) {
                    	case 1 :
                    	    // ./src/COOLTreeBuilder.g:147:29: ID ':' TYPE '=>' expr ';'
                    	    {
                    	    ID104=(Token)match(input,ID,FOLLOW_ID_in_atom1081); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    ID104_tree = (CommonTree)adaptor.create(ID104);
                    	    adaptor.addChild(root_0, ID104_tree);
                    	    }
                    	    char_literal105=(Token)match(input,52,FOLLOW_52_in_atom1083); if (state.failed) return retval;
                    	    TYPE106=(Token)match(input,TYPE,FOLLOW_TYPE_in_atom1086); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    TYPE106_tree = (CommonTree)adaptor.create(TYPE106);
                    	    adaptor.addChild(root_0, TYPE106_tree);
                    	    }
                    	    string_literal107=(Token)match(input,64,FOLLOW_64_in_atom1088); if (state.failed) return retval;
                    	    pushFollow(FOLLOW_expr_in_atom1091);
                    	    expr108=expr();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr108.getTree());
                    	    char_literal109=(Token)match(input,46,FOLLOW_46_in_atom1093); if (state.failed) return retval;

                    	    }
                    	    break;

                    	default :
                    	    if ( cnt22 >= 1 ) break loop22;
                    	    if (state.backtracking>0) {state.failed=true; return retval;}
                                EarlyExitException eee =
                                    new EarlyExitException(22, input);
                                throw eee;
                        }
                        cnt22++;
                    } while (true);

                    ESAC_ST110=(Token)match(input,ESAC_ST,FOLLOW_ESAC_ST_in_atom1098); if (state.failed) return retval;

                    }
                    break;
                case 13 :
                    // ./src/COOLTreeBuilder.g:148:7: LET_ST ID ':' TYPE ( '<-' expr )? ( ',' ID ':' TYPE ( '<-' expr )? )* IN_ST expr
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    LET_ST111=(Token)match(input,LET_ST,FOLLOW_LET_ST_in_atom1108); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    LET_ST111_tree = (CommonTree)adaptor.create(LET_ST111);
                    root_0 = (CommonTree)adaptor.becomeRoot(LET_ST111_tree, root_0);
                    }
                    ID112=(Token)match(input,ID,FOLLOW_ID_in_atom1111); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    ID112_tree = (CommonTree)adaptor.create(ID112);
                    adaptor.addChild(root_0, ID112_tree);
                    }
                    char_literal113=(Token)match(input,52,FOLLOW_52_in_atom1113); if (state.failed) return retval;
                    TYPE114=(Token)match(input,TYPE,FOLLOW_TYPE_in_atom1116); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                    TYPE114_tree = (CommonTree)adaptor.create(TYPE114);
                    adaptor.addChild(root_0, TYPE114_tree);
                    }
                    // ./src/COOLTreeBuilder.g:148:28: ( '<-' expr )?
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==53) ) {
                        alt23=1;
                    }
                    switch (alt23) {
                        case 1 :
                            // ./src/COOLTreeBuilder.g:148:29: '<-' expr
                            {
                            string_literal115=(Token)match(input,53,FOLLOW_53_in_atom1119); if (state.failed) return retval;
                            if ( state.backtracking==0 ) {
                            string_literal115_tree = (CommonTree)adaptor.create(string_literal115);
                            adaptor.addChild(root_0, string_literal115_tree);
                            }
                            pushFollow(FOLLOW_expr_in_atom1121);
                            expr116=expr();

                            state._fsp--;
                            if (state.failed) return retval;
                            if ( state.backtracking==0 ) adaptor.addChild(root_0, expr116.getTree());

                            }
                            break;

                    }

                    // ./src/COOLTreeBuilder.g:148:41: ( ',' ID ':' TYPE ( '<-' expr )? )*
                    loop25:
                    do {
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==50) ) {
                            alt25=1;
                        }


                        switch (alt25) {
                    	case 1 :
                    	    // ./src/COOLTreeBuilder.g:148:42: ',' ID ':' TYPE ( '<-' expr )?
                    	    {
                    	    char_literal117=(Token)match(input,50,FOLLOW_50_in_atom1126); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    char_literal117_tree = (CommonTree)adaptor.create(char_literal117);
                    	    adaptor.addChild(root_0, char_literal117_tree);
                    	    }
                    	    ID118=(Token)match(input,ID,FOLLOW_ID_in_atom1128); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    ID118_tree = (CommonTree)adaptor.create(ID118);
                    	    adaptor.addChild(root_0, ID118_tree);
                    	    }
                    	    char_literal119=(Token)match(input,52,FOLLOW_52_in_atom1130); if (state.failed) return retval;
                    	    TYPE120=(Token)match(input,TYPE,FOLLOW_TYPE_in_atom1133); if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	    TYPE120_tree = (CommonTree)adaptor.create(TYPE120);
                    	    adaptor.addChild(root_0, TYPE120_tree);
                    	    }
                    	    // ./src/COOLTreeBuilder.g:148:59: ( '<-' expr )?
                    	    int alt24=2;
                    	    int LA24_0 = input.LA(1);

                    	    if ( (LA24_0==53) ) {
                    	        alt24=1;
                    	    }
                    	    switch (alt24) {
                    	        case 1 :
                    	            // ./src/COOLTreeBuilder.g:148:60: '<-' expr
                    	            {
                    	            string_literal121=(Token)match(input,53,FOLLOW_53_in_atom1136); if (state.failed) return retval;
                    	            if ( state.backtracking==0 ) {
                    	            string_literal121_tree = (CommonTree)adaptor.create(string_literal121);
                    	            adaptor.addChild(root_0, string_literal121_tree);
                    	            }
                    	            pushFollow(FOLLOW_expr_in_atom1138);
                    	            expr122=expr();

                    	            state._fsp--;
                    	            if (state.failed) return retval;
                    	            if ( state.backtracking==0 ) adaptor.addChild(root_0, expr122.getTree());

                    	            }
                    	            break;

                    	    }


                    	    }
                    	    break;

                    	default :
                    	    break loop25;
                        }
                    } while (true);

                    IN_ST123=(Token)match(input,IN_ST,FOLLOW_IN_ST_in_atom1144); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_atom1147);
                    expr124=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    if ( state.backtracking==0 ) adaptor.addChild(root_0, expr124.getTree());

                    }
                    break;

            }
            retval.stop = input.LT(-1);

            if ( state.backtracking==0 ) {

            retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
            adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);
            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
    	retval.tree = (CommonTree)adaptor.errorNode(input, retval.start, input.LT(-1), re);

        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "atom"

    // $ANTLR start synpred1_COOLTreeBuilder
    public final void synpred1_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:79:5: ( '<=' )
        // ./src/COOLTreeBuilder.g:79:6: '<='
        {
        match(input,54,FOLLOW_54_in_synpred1_COOLTreeBuilder565); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_COOLTreeBuilder

    // $ANTLR start synpred2_COOLTreeBuilder
    public final void synpred2_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:81:5: ( '<' )
        // ./src/COOLTreeBuilder.g:81:6: '<'
        {
        match(input,55,FOLLOW_55_in_synpred2_COOLTreeBuilder586); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_COOLTreeBuilder

    // $ANTLR start synpred3_COOLTreeBuilder
    public final void synpred3_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:83:5: ( '=' )
        // ./src/COOLTreeBuilder.g:83:6: '='
        {
        match(input,56,FOLLOW_56_in_synpred3_COOLTreeBuilder607); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred3_COOLTreeBuilder

    // $ANTLR start synpred4_COOLTreeBuilder
    public final void synpred4_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:91:5: ( '+' )
        // ./src/COOLTreeBuilder.g:91:6: '+'
        {
        match(input,57,FOLLOW_57_in_synpred4_COOLTreeBuilder646); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred4_COOLTreeBuilder

    // $ANTLR start synpred5_COOLTreeBuilder
    public final void synpred5_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:93:5: ( '-' )
        // ./src/COOLTreeBuilder.g:93:6: '-'
        {
        match(input,58,FOLLOW_58_in_synpred5_COOLTreeBuilder667); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred5_COOLTreeBuilder

    // $ANTLR start synpred6_COOLTreeBuilder
    public final void synpred6_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:101:5: ( '*' )
        // ./src/COOLTreeBuilder.g:101:6: '*'
        {
        match(input,59,FOLLOW_59_in_synpred6_COOLTreeBuilder706); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred6_COOLTreeBuilder

    // $ANTLR start synpred7_COOLTreeBuilder
    public final void synpred7_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:103:5: ( '/' )
        // ./src/COOLTreeBuilder.g:103:6: '/'
        {
        match(input,60,FOLLOW_60_in_synpred7_COOLTreeBuilder727); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred7_COOLTreeBuilder

    // $ANTLR start synpred8_COOLTreeBuilder
    public final void synpred8_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:124:5: ( '@' )
        // ./src/COOLTreeBuilder.g:124:6: '@'
        {
        match(input,62,FOLLOW_62_in_synpred8_COOLTreeBuilder823); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred8_COOLTreeBuilder

    // $ANTLR start synpred9_COOLTreeBuilder
    public final void synpred9_COOLTreeBuilder_fragment() throws RecognitionException {   
        // ./src/COOLTreeBuilder.g:127:4: ( '.' dispatchExprAux )
        // ./src/COOLTreeBuilder.g:127:5: '.' dispatchExprAux
        {
        match(input,63,FOLLOW_63_in_synpred9_COOLTreeBuilder847); if (state.failed) return ;
        pushFollow(FOLLOW_dispatchExprAux_in_synpred9_COOLTreeBuilder849);
        dispatchExprAux();

        state._fsp--;
        if (state.failed) return ;

        }
    }
    // $ANTLR end synpred9_COOLTreeBuilder

    // Delegated rules

    public final boolean synpred8_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred8_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred9_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred9_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred6_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred6_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred4_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred4_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred1_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred7_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred7_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred3_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred3_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred5_COOLTreeBuilder() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred5_COOLTreeBuilder_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA26 dfa26 = new DFA26(this);
    static final String DFA26_eotS =
        "\17\uffff";
    static final String DFA26_eofS =
        "\17\uffff";
    static final String DFA26_minS =
        "\1\26\1\uffff\1\37\14\uffff";
    static final String DFA26_maxS =
        "\1\61\1\uffff\1\77\14\uffff";
    static final String DFA26_acceptS =
        "\1\uffff\1\1\1\uffff\1\3\1\4\1\5\1\6\1\10\1\11\1\12\1\13\1\14\1"+
        "\15\1\7\1\2";
    static final String DFA26_specialS =
        "\17\uffff}>";
    static final String[] DFA26_transitionS = {
            "\1\2\2\uffff\1\1\1\4\1\5\1\6\1\10\1\11\3\uffff\1\12\2\uffff"+
            "\1\13\2\uffff\1\14\6\uffff\1\7\1\uffff\1\3",
            "",
            "\3\16\1\uffff\2\16\1\uffff\1\16\2\uffff\1\16\4\uffff\1\16\1"+
            "\uffff\1\16\1\15\2\16\2\uffff\7\16\1\uffff\2\16",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            ""
    };

    static final short[] DFA26_eot = DFA.unpackEncodedString(DFA26_eotS);
    static final short[] DFA26_eof = DFA.unpackEncodedString(DFA26_eofS);
    static final char[] DFA26_min = DFA.unpackEncodedStringToUnsignedChars(DFA26_minS);
    static final char[] DFA26_max = DFA.unpackEncodedStringToUnsignedChars(DFA26_maxS);
    static final short[] DFA26_accept = DFA.unpackEncodedString(DFA26_acceptS);
    static final short[] DFA26_special = DFA.unpackEncodedString(DFA26_specialS);
    static final short[][] DFA26_transition;

    static {
        int numStates = DFA26_transitionS.length;
        DFA26_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA26_transition[i] = DFA.unpackEncodedString(DFA26_transitionS[i]);
        }
    }

    class DFA26 extends DFA {

        public DFA26(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 26;
            this.eot = DFA26_eot;
            this.eof = DFA26_eof;
            this.min = DFA26_min;
            this.max = DFA26_max;
            this.accept = DFA26_accept;
            this.special = DFA26_special;
            this.transition = DFA26_transition;
        }
        public String getDescription() {
            return "135:1: atom : ( INTEGER | ID | '(' expr ')' | TRUE_ST | FALSE_ST | STRING | ID '(' ( expr ( ',' expr )* )? ')' -> ^( CALL_T ID ( expr )* ) | '{' ( expr ';' )+ '}' | NEW_ST TYPE | IF_ST expr THEN_ST expr ELSE_ST expr FI_ST | WHILE_ST expr LOOP_ST expr POOL_ST | CASE_ST expr OF_ST ( ID ':' TYPE '=>' expr ';' )+ ESAC_ST | LET_ST ID ':' TYPE ( '<-' expr )? ( ',' ID ':' TYPE ( '<-' expr )? )* IN_ST expr );";
        }
    }
 

    public static final BitSet FOLLOW_class_stat_in_program266 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_46_in_program268 = new BitSet(new long[]{0x0000000000080002L});
    public static final BitSet FOLLOW_CLASS_ST_in_class_stat290 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_class_stat294 = new BitSet(new long[]{0x0000800000200000L});
    public static final BitSet FOLLOW_INHERITS_ST_in_class_stat297 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_class_stat301 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_47_in_class_stat305 = new BitSet(new long[]{0x0001000000400000L});
    public static final BitSet FOLLOW_feature_in_class_stat308 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_46_in_class_stat310 = new BitSet(new long[]{0x0001000000400000L});
    public static final BitSet FOLLOW_48_in_class_stat314 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_feature350 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_49_in_feature352 = new BitSet(new long[]{0x0008000000400000L});
    public static final BitSet FOLLOW_formal_in_feature355 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_50_in_feature358 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_formal_in_feature360 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_51_in_feature366 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_52_in_feature368 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_feature372 = new BitSet(new long[]{0x0000800000000000L});
    public static final BitSet FOLLOW_47_in_feature374 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_feature376 = new BitSet(new long[]{0x0001000000000000L});
    public static final BitSet FOLLOW_48_in_feature378 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_feature409 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_52_in_feature411 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_feature413 = new BitSet(new long[]{0x0020000000000002L});
    public static final BitSet FOLLOW_53_in_feature416 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_feature418 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_formal454 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_52_in_formal456 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_formal458 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_assignExpr_in_expr483 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_assignExpr498 = new BitSet(new long[]{0x0020000000000000L});
    public static final BitSet FOLLOW_53_in_assignExpr500 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_assignExpr_in_assignExpr503 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_notExpr_in_assignExpr511 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NOT_ST_in_notExpr527 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_notExpr_in_notExpr530 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_relExpr_in_notExpr539 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_sumExpr_in_relExpr554 = new BitSet(new long[]{0x01C0000000000002L});
    public static final BitSet FOLLOW_54_in_relExpr570 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_sumExpr_in_relExpr573 = new BitSet(new long[]{0x01C0000000000002L});
    public static final BitSet FOLLOW_55_in_relExpr591 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_sumExpr_in_relExpr594 = new BitSet(new long[]{0x01C0000000000002L});
    public static final BitSet FOLLOW_56_in_relExpr612 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_sumExpr_in_relExpr615 = new BitSet(new long[]{0x01C0000000000002L});
    public static final BitSet FOLLOW_multExpr_in_sumExpr635 = new BitSet(new long[]{0x0600000000000002L});
    public static final BitSet FOLLOW_57_in_sumExpr651 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_multExpr_in_sumExpr654 = new BitSet(new long[]{0x0600000000000002L});
    public static final BitSet FOLLOW_58_in_sumExpr672 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_multExpr_in_sumExpr675 = new BitSet(new long[]{0x0600000000000002L});
    public static final BitSet FOLLOW_isVoidExpr_in_multExpr695 = new BitSet(new long[]{0x1800000000000002L});
    public static final BitSet FOLLOW_59_in_multExpr711 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_isVoidExpr_in_multExpr714 = new BitSet(new long[]{0x1800000000000002L});
    public static final BitSet FOLLOW_60_in_multExpr733 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_isVoidExpr_in_multExpr736 = new BitSet(new long[]{0x1800000000000002L});
    public static final BitSet FOLLOW_ISVOID_ST_in_isVoidExpr758 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_isVoidExpr_in_isVoidExpr761 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_tildaExpr_in_isVoidExpr770 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_61_in_tildaExpr786 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_tildaExpr_in_tildaExpr789 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_dispatchExpr_in_tildaExpr798 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_atom_in_dispatchExpr814 = new BitSet(new long[]{0xC000000000000002L});
    public static final BitSet FOLLOW_62_in_dispatchExpr828 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_dispatchExpr831 = new BitSet(new long[]{0x8000000000000002L});
    public static final BitSet FOLLOW_63_in_dispatchExpr854 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_dispatchExprAux_in_dispatchExpr857 = new BitSet(new long[]{0x8000000000000002L});
    public static final BitSet FOLLOW_ID_in_dispatchExprAux874 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_49_in_dispatchExprAux876 = new BitSet(new long[]{0x200A81247FC00000L});
    public static final BitSet FOLLOW_expr_in_dispatchExprAux880 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_50_in_dispatchExprAux883 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_dispatchExprAux886 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_51_in_dispatchExprAux892 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_INTEGER_in_atom908 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom916 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_49_in_atom924 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom927 = new BitSet(new long[]{0x0008000000000000L});
    public static final BitSet FOLLOW_51_in_atom929 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_TRUE_ST_in_atom938 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FALSE_ST_in_atom946 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_STRING_in_atom954 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_atom962 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_49_in_atom964 = new BitSet(new long[]{0x200A81247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom967 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_50_in_atom970 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom972 = new BitSet(new long[]{0x000C000000000000L});
    public static final BitSet FOLLOW_51_in_atom978 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_47_in_atom996 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1000 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_46_in_atom1002 = new BitSet(new long[]{0x200381247FC00000L});
    public static final BitSet FOLLOW_48_in_atom1007 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEW_ST_in_atom1016 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_atom1019 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_IF_ST_in_atom1027 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1030 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_THEN_ST_in_atom1032 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1035 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_ELSE_ST_in_atom1037 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1040 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_FI_ST_in_atom1042 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_WHILE_ST_in_atom1052 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1055 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_LOOP_ST_in_atom1057 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1060 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_POOL_ST_in_atom1062 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_CASE_ST_in_atom1072 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1075 = new BitSet(new long[]{0x0000004000000000L});
    public static final BitSet FOLLOW_OF_ST_in_atom1077 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_ID_in_atom1081 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_52_in_atom1083 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_atom1086 = new BitSet(new long[]{0x0000000000000000L,0x0000000000000001L});
    public static final BitSet FOLLOW_64_in_atom1088 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1091 = new BitSet(new long[]{0x0000400000000000L});
    public static final BitSet FOLLOW_46_in_atom1093 = new BitSet(new long[]{0x0000008000400000L});
    public static final BitSet FOLLOW_ESAC_ST_in_atom1098 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LET_ST_in_atom1108 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_ID_in_atom1111 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_52_in_atom1113 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_atom1116 = new BitSet(new long[]{0x0024020000000000L});
    public static final BitSet FOLLOW_53_in_atom1119 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1121 = new BitSet(new long[]{0x0004020000000000L});
    public static final BitSet FOLLOW_50_in_atom1126 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_ID_in_atom1128 = new BitSet(new long[]{0x0010000000000000L});
    public static final BitSet FOLLOW_52_in_atom1130 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_atom1133 = new BitSet(new long[]{0x0024020000000000L});
    public static final BitSet FOLLOW_53_in_atom1136 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1138 = new BitSet(new long[]{0x0004020000000000L});
    public static final BitSet FOLLOW_IN_ST_in_atom1144 = new BitSet(new long[]{0x200281247FC00000L});
    public static final BitSet FOLLOW_expr_in_atom1147 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_54_in_synpred1_COOLTreeBuilder565 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_55_in_synpred2_COOLTreeBuilder586 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_56_in_synpred3_COOLTreeBuilder607 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_57_in_synpred4_COOLTreeBuilder646 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_58_in_synpred5_COOLTreeBuilder667 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_59_in_synpred6_COOLTreeBuilder706 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_60_in_synpred7_COOLTreeBuilder727 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_62_in_synpred8_COOLTreeBuilder823 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_63_in_synpred9_COOLTreeBuilder847 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_dispatchExprAux_in_synpred9_COOLTreeBuilder849 = new BitSet(new long[]{0x0000000000000002L});

}