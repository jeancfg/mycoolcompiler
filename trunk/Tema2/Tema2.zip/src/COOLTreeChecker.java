// $ANTLR 3.2 Sep 23, 2009 12:02:23 ./src/COOLTreeChecker.g 2009-11-15 23:00:55

  import java.util.LinkedList;


import org.antlr.runtime.*;
import org.antlr.runtime.tree.*;import java.util.Stack;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
public class COOLTreeChecker extends TreeParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "CLASS_T", "BLOCK_T", "CALL_T", "FEATURES_T", "ASSIGN_T", "METHOD_T", "BOOL_T", "EXPR_T", "RETURN_TYPE_T", "TYPE_ID", "FORMALS_T", "ATTR_T", "ID_T", "INTEGER_T", "OP_T", "CLASS_ST", "TYPE", "INHERITS_ST", "ID", "NOT_ST", "ISVOID_ST", "INTEGER", "TRUE_ST", "FALSE_ST", "STRING", "NEW_ST", "IF_ST", "THEN_ST", "ELSE_ST", "FI_ST", "WHILE_ST", "LOOP_ST", "POOL_ST", "CASE_ST", "OF_ST", "ESAC_ST", "LET_ST", "IN_ST", "MULTI_COMMENT", "SINGLE_COMMENT", "ESC_SEQ", "WS", "';'", "'{'", "'}'", "'('", "','", "')'", "':'", "'<-'", "'<='", "'<'", "'='", "'+'", "'-'", "'*'", "'/'", "'~'", "'@'", "'.'", "'=>'"
    };
    public static final int T__64=64;
    public static final int T__62=62;
    public static final int T__63=63;
    public static final int CLASS_T=4;
    public static final int TRUE_ST=26;
    public static final int LET_ST=40;
    public static final int CLASS_ST=19;
    public static final int MULTI_COMMENT=42;
    public static final int FI_ST=33;
    public static final int ID=22;
    public static final int T__61=61;
    public static final int T__60=60;
    public static final int EOF=-1;
    public static final int LOOP_ST=35;
    public static final int IN_ST=41;
    public static final int TYPE=20;
    public static final int EXPR_T=11;
    public static final int T__55=55;
    public static final int NOT_ST=23;
    public static final int T__56=56;
    public static final int T__57=57;
    public static final int INTEGER_T=17;
    public static final int T__58=58;
    public static final int ESC_SEQ=44;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int T__59=59;
    public static final int ASSIGN_T=8;
    public static final int INHERITS_ST=21;
    public static final int SINGLE_COMMENT=43;
    public static final int ATTR_T=15;
    public static final int BLOCK_T=5;
    public static final int T__50=50;
    public static final int INTEGER=25;
    public static final int T__46=46;
    public static final int WHILE_ST=34;
    public static final int T__47=47;
    public static final int FEATURES_T=7;
    public static final int OF_ST=38;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int ELSE_ST=32;
    public static final int BOOL_T=10;
    public static final int METHOD_T=9;
    public static final int OP_T=18;
    public static final int POOL_ST=36;
    public static final int RETURN_TYPE_T=12;
    public static final int IF_ST=30;
    public static final int ISVOID_ST=24;
    public static final int ID_T=16;
    public static final int CASE_ST=37;
    public static final int ESAC_ST=39;
    public static final int WS=45;
    public static final int NEW_ST=29;
    public static final int FALSE_ST=27;
    public static final int CALL_T=6;
    public static final int TYPE_ID=13;
    public static final int FORMALS_T=14;
    public static final int STRING=28;
    public static final int THEN_ST=31;

    // delegates
    // delegators


        public COOLTreeChecker(TreeNodeStream input) {
            this(input, new RecognizerSharedState());
        }
        public COOLTreeChecker(TreeNodeStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return COOLTreeChecker.tokenNames; }
    public String getGrammarFileName() { return "./src/COOLTreeChecker.g"; }


      // Do not touch; variabile folosite pentru '@'
      int static_dispatchLine = -1;
      Expression static_dispatchExpr = null;
      AbstractSymbol static_dispatchObj = null;
      int level = 0;
      int static_dispatchLevel = 0;
      // End
      
    	private String fileName = "Unnamed"; // The file name is needed by the tree API.
    	
    	public String getFileName() { return fileName; }
    	public void setFileName(String fileName) { this.fileName = fileName; }
    	
    	private Expression applyOp(String op, int line, Expression __name, Expression __expr)
    	{
    	 Expression result = null;
    	 
    	 if (op.equals("+"))
    	   result = new plus(line, __name, __expr);
    	 else if (op.equals("-"))
    	   result = new sub(line, __name, __expr);
    	 else if (op.equals("*"))
    	   result = new mul(line, __name, __expr);
    	 else if (op.equals("/"))
    	   result = new divide(line, __name, __expr);
    	 else if (op.equals("<"))
    	   result = new lt(line, __name, __expr);
    	 else if (op.equals("<="))
    	   result = new leq(line, __name, __expr);
    	 else if (op.equals("="))
    	   result = new eq(line, __name, __expr);
    	 else
    	   System.out.println("Unknown operator " + op);
    	   
    	 return result;
    	}
    	

      private static boolean isESQ(char c) {
        return c == 'b' || c == '\b' || c == 't' || c == '\t' || c == 'n'
            || c == '\n' || c == 'f' || c == '\f' || c == 'r' || c == '\r'
            || c == '\"' || c == '\'' || c == '\\';
      }

      private static char normESQ(char c) {
        if (c == 'b')
          return '\b';
        if (c == 't')
          return '\t';
        if (c == 'n')
          return '\n';
        if (c == 'f')
          return '\f';
        return c;
      }

      public static String normalize(String str) {
        int size = str.length();
        StringBuilder s = new StringBuilder();
        char aux;
        
        for (int  i = 1 ; i < size - 1 ; i++)
        {
          if (str.charAt(i) == '\n')
            if (i > 0 && str.charAt(i - 1) != '\\')
              return null;
            else if (i > 1 && str.charAt(i - 1) == '\\' && str.charAt(i - 2) == '\\')
              return null;
        }

        for (int i = 1; i < size - 1;) {
          if (str.charAt(i) == '\\') {
            if (i < size - 1 && isESQ(str.charAt(i + 1))) {
              s.append(normESQ(str.charAt(i + 1)));
              i += 2;
            } else {
              s.append(str.charAt(++i));
              i++;
            }
          } else {
            s.append(str.charAt(i));
            i++;
          }
        }

        return s.toString();
      }



    // $ANTLR start "program"
    // ./src/COOLTreeChecker.g:102:1: program[Classes cl] : ( classdef )+ ;
    public final void program(Classes cl) throws RecognitionException {
        class_ classdef1 = null;


        try {
            // ./src/COOLTreeChecker.g:103:3: ( ( classdef )+ )
            // ./src/COOLTreeChecker.g:104:3: ( classdef )+
            {
            // ./src/COOLTreeChecker.g:104:3: ( classdef )+
            int cnt1=0;
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==CLASS_T) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // ./src/COOLTreeChecker.g:105:5: classdef
            	    {
            	    pushFollow(FOLLOW_classdef_in_program60);
            	    classdef1=classdef();

            	    state._fsp--;
            	    if (state.failed) return ;
            	    if ( state.backtracking==0 ) {
            	       cl.appendElement(classdef1); 
            	    }

            	    }
            	    break;

            	default :
            	    if ( cnt1 >= 1 ) break loop1;
            	    if (state.backtracking>0) {state.failed=true; return ;}
                        EarlyExitException eee =
                            new EarlyExitException(1, input);
                        throw eee;
                }
                cnt1++;
            } while (true);


            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return ;
    }
    // $ANTLR end "program"


    // $ANTLR start "classdef"
    // ./src/COOLTreeChecker.g:109:1: classdef returns [class_ result] : ( ^( CLASS_T name= TYPE features ) | ^( CLASS_T name= TYPE parent= TYPE features ) );
    public final class_ classdef() throws RecognitionException {
        class_ result = null;

        CommonTree name=null;
        CommonTree parent=null;
        CommonTree CLASS_T2=null;
        CommonTree CLASS_T4=null;
        Features features3 = null;

        Features features5 = null;


        try {
            // ./src/COOLTreeChecker.g:110:3: ( ^( CLASS_T name= TYPE features ) | ^( CLASS_T name= TYPE parent= TYPE features ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==CLASS_T) ) {
                int LA2_1 = input.LA(2);

                if ( (LA2_1==DOWN) ) {
                    int LA2_2 = input.LA(3);

                    if ( (LA2_2==TYPE) ) {
                        int LA2_3 = input.LA(4);

                        if ( (LA2_3==TYPE) ) {
                            alt2=2;
                        }
                        else if ( (LA2_3==FEATURES_T) ) {
                            alt2=1;
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return result;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 2, 3, input);

                            throw nvae;
                        }
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return result;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 2, 2, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 2, 1, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // ./src/COOLTreeChecker.g:111:3: ^( CLASS_T name= TYPE features )
                    {
                    CLASS_T2=(CommonTree)match(input,CLASS_T,FOLLOW_CLASS_T_in_classdef87); if (state.failed) return result;

                    match(input, Token.DOWN, null); if (state.failed) return result;
                    name=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_classdef91); if (state.failed) return result;
                    pushFollow(FOLLOW_features_in_classdef93);
                    features3=features();

                    state._fsp--;
                    if (state.failed) return result;

                    match(input, Token.UP, null); if (state.failed) return result;
                    if ( state.backtracking==0 ) {

                        	result = new class_((CLASS_T2!=null?CLASS_T2.getLine():0),
                      			AbstractTable.idtable.addString((name!=null?name.getText():null)),
                      			AbstractTable.idtable.addString("Object"),
                      			features3,
                      			AbstractTable.stringtable.addString(getFileName()));
                      	
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:120:3: ^( CLASS_T name= TYPE parent= TYPE features )
                    {
                    CLASS_T4=(CommonTree)match(input,CLASS_T,FOLLOW_CLASS_T_in_classdef107); if (state.failed) return result;

                    match(input, Token.DOWN, null); if (state.failed) return result;
                    name=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_classdef111); if (state.failed) return result;
                    parent=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_classdef115); if (state.failed) return result;
                    pushFollow(FOLLOW_features_in_classdef117);
                    features5=features();

                    state._fsp--;
                    if (state.failed) return result;

                    match(input, Token.UP, null); if (state.failed) return result;
                    if ( state.backtracking==0 ) {

                      		result = new class_((CLASS_T4!=null?CLASS_T4.getLine():0),
                      			AbstractTable.idtable.addString((name!=null?name.getText():null)),
                      			AbstractTable.idtable.addString((parent!=null?parent.getText():null)),
                      			features5,
                      			AbstractTable.stringtable.addString(getFileName()));
                      	
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end "classdef"


    // $ANTLR start "features"
    // ./src/COOLTreeChecker.g:130:1: features returns [Features result] : ^( FEATURES_T ( feature )* ) ;
    public final Features features() throws RecognitionException {
        Features result = null;

        CommonTree FEATURES_T6=null;
        Feature feature7 = null;


        try {
            // ./src/COOLTreeChecker.g:131:3: ( ^( FEATURES_T ( feature )* ) )
            // ./src/COOLTreeChecker.g:132:3: ^( FEATURES_T ( feature )* )
            {
            FEATURES_T6=(CommonTree)match(input,FEATURES_T,FOLLOW_FEATURES_T_in_features147); if (state.failed) return result;

            if ( state.backtracking==0 ) {
               result = new Features((FEATURES_T6!=null?FEATURES_T6.getLine():0)); 
            }

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return result;
                // ./src/COOLTreeChecker.g:134:5: ( feature )*
                loop3:
                do {
                    int alt3=2;
                    int LA3_0 = input.LA(1);

                    if ( (LA3_0==METHOD_T||LA3_0==ATTR_T) ) {
                        alt3=1;
                    }


                    switch (alt3) {
                	case 1 :
                	    // ./src/COOLTreeChecker.g:135:7: feature
                	    {
                	    pushFollow(FOLLOW_feature_in_features163);
                	    feature7=feature();

                	    state._fsp--;
                	    if (state.failed) return result;
                	    if ( state.backtracking==0 ) {
                	       result.appendElement(feature7); 
                	    }

                	    }
                	    break;

                	default :
                	    break loop3;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return result;
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end "features"


    // $ANTLR start "feature"
    // ./src/COOLTreeChecker.g:140:1: feature returns [Feature result] : ( ^( METHOD_T name= ID type= TYPE formals expr ) | ^( ATTR_T name= ID type= TYPE ) | ^( ATTR_T name= ID type= TYPE e= expr ) );
    public final Feature feature() throws RecognitionException {
        Feature result = null;

        CommonTree name=null;
        CommonTree type=null;
        CommonTree METHOD_T8=null;
        CommonTree ATTR_T11=null;
        CommonTree ATTR_T12=null;
        COOLTreeChecker.expr_return e = null;

        Formals formals9 = null;

        COOLTreeChecker.expr_return expr10 = null;


        try {
            // ./src/COOLTreeChecker.g:141:3: ( ^( METHOD_T name= ID type= TYPE formals expr ) | ^( ATTR_T name= ID type= TYPE ) | ^( ATTR_T name= ID type= TYPE e= expr ) )
            int alt4=3;
            int LA4_0 = input.LA(1);

            if ( (LA4_0==METHOD_T) ) {
                alt4=1;
            }
            else if ( (LA4_0==ATTR_T) ) {
                int LA4_2 = input.LA(2);

                if ( (LA4_2==DOWN) ) {
                    int LA4_3 = input.LA(3);

                    if ( (LA4_3==ID) ) {
                        int LA4_4 = input.LA(4);

                        if ( (LA4_4==TYPE) ) {
                            int LA4_5 = input.LA(5);

                            if ( (LA4_5==UP) ) {
                                alt4=2;
                            }
                            else if ( (LA4_5==CALL_T||LA4_5==EXPR_T||(LA4_5>=ID && LA4_5<=IF_ST)||LA4_5==WHILE_ST||LA4_5==CASE_ST||LA4_5==LET_ST||LA4_5==47||(LA4_5>=53 && LA4_5<=63)) ) {
                                alt4=3;
                            }
                            else {
                                if (state.backtracking>0) {state.failed=true; return result;}
                                NoViableAltException nvae =
                                    new NoViableAltException("", 4, 5, input);

                                throw nvae;
                            }
                        }
                        else {
                            if (state.backtracking>0) {state.failed=true; return result;}
                            NoViableAltException nvae =
                                new NoViableAltException("", 4, 4, input);

                            throw nvae;
                        }
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return result;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 4, 3, input);

                        throw nvae;
                    }
                }
                else {
                    if (state.backtracking>0) {state.failed=true; return result;}
                    NoViableAltException nvae =
                        new NoViableAltException("", 4, 2, input);

                    throw nvae;
                }
            }
            else {
                if (state.backtracking>0) {state.failed=true; return result;}
                NoViableAltException nvae =
                    new NoViableAltException("", 4, 0, input);

                throw nvae;
            }
            switch (alt4) {
                case 1 :
                    // ./src/COOLTreeChecker.g:142:3: ^( METHOD_T name= ID type= TYPE formals expr )
                    {
                    METHOD_T8=(CommonTree)match(input,METHOD_T,FOLLOW_METHOD_T_in_feature197); if (state.failed) return result;

                    match(input, Token.DOWN, null); if (state.failed) return result;
                    name=(CommonTree)match(input,ID,FOLLOW_ID_in_feature201); if (state.failed) return result;
                    type=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_feature205); if (state.failed) return result;
                    pushFollow(FOLLOW_formals_in_feature207);
                    formals9=formals();

                    state._fsp--;
                    if (state.failed) return result;
                    pushFollow(FOLLOW_expr_in_feature209);
                    expr10=expr();

                    state._fsp--;
                    if (state.failed) return result;

                    match(input, Token.UP, null); if (state.failed) return result;
                    if ( state.backtracking==0 ) {

                          AbstractSymbol returnType = AbstractTable.idtable.addString((type!=null?type.getText():null));    
                          result = new method((METHOD_T8!=null?METHOD_T8.getLine():0), AbstractTable.idtable.addString((name!=null?name.getText():null)),
                              formals9, returnType, (expr10!=null?expr10.result:null));
                        
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:149:3: ^( ATTR_T name= ID type= TYPE )
                    {
                    ATTR_T11=(CommonTree)match(input,ATTR_T,FOLLOW_ATTR_T_in_feature223); if (state.failed) return result;

                    match(input, Token.DOWN, null); if (state.failed) return result;
                    name=(CommonTree)match(input,ID,FOLLOW_ID_in_feature227); if (state.failed) return result;
                    type=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_feature231); if (state.failed) return result;

                    match(input, Token.UP, null); if (state.failed) return result;
                    if ( state.backtracking==0 ) {

                          result = new attr((ATTR_T11!=null?ATTR_T11.getLine():0), AbstractTable.idtable.addString((name!=null?name.getText():null)),
                            AbstractTable.idtable.addString((type!=null?type.getText():null)), new no_expr(0));
                        
                    }

                    }
                    break;
                case 3 :
                    // ./src/COOLTreeChecker.g:155:3: ^( ATTR_T name= ID type= TYPE e= expr )
                    {
                    ATTR_T12=(CommonTree)match(input,ATTR_T,FOLLOW_ATTR_T_in_feature245); if (state.failed) return result;

                    match(input, Token.DOWN, null); if (state.failed) return result;
                    name=(CommonTree)match(input,ID,FOLLOW_ID_in_feature249); if (state.failed) return result;
                    type=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_feature253); if (state.failed) return result;
                    pushFollow(FOLLOW_expr_in_feature257);
                    e=expr();

                    state._fsp--;
                    if (state.failed) return result;

                    match(input, Token.UP, null); if (state.failed) return result;
                    if ( state.backtracking==0 ) {

                          Expression __expr = (e!=null?e.result:null);
                          __expr.set_type((e!=null?e.returnType:null));
                          
                          result = new attr((ATTR_T12!=null?ATTR_T12.getLine():0), AbstractTable.idtable.addString((name!=null?name.getText():null)),
                            AbstractTable.idtable.addString((type!=null?type.getText():null)), __expr);
                        
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end "feature"

    public static class expr_return extends TreeRuleReturnScope {
        public Expression result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "expr"
    // ./src/COOLTreeChecker.g:165:1: expr returns [Expression result, AbstractSymbol returnType] : ( ( ^( EXPR_T l= let ) | l= let ) | ( ^( EXPR_T bl= block ) | bl= block ) | ( ^( EXPR_T c= call ) | c= call ) | ( ^( EXPR_T i= INTEGER ) | i= INTEGER ) | ( ^( EXPR_T s= STRING ) | s= STRING ) | ( ^( EXPR_T o= op ) | o= op ) | ( ^( EXPR_T id= ID ) | id= ID ) | ( ^( EXPR_T b= TRUE_ST ) | b= TRUE_ST ) | ( ^( EXPR_T b= FALSE_ST ) | b= FALSE_ST ) | ( ^( EXPR_T w= while_r ) | w= while_r ) | ( ^( EXPR_T if_r_= if_r ) | if_r_= if_r ) | ( ^( EXPR_T case_r_= case_r ) | case_r_= case_r ) | ( ^( EXPR_T new_r_= new_r ) | new_r_= new_r ) );
    public final COOLTreeChecker.expr_return expr() throws RecognitionException {
        COOLTreeChecker.expr_return retval = new COOLTreeChecker.expr_return();
        retval.start = input.LT(1);

        CommonTree i=null;
        CommonTree s=null;
        CommonTree id=null;
        CommonTree b=null;
        COOLTreeChecker.let_return l = null;

        COOLTreeChecker.block_return bl = null;

        COOLTreeChecker.call_return c = null;

        COOLTreeChecker.op_return o = null;

        COOLTreeChecker.while_r_return w = null;

        COOLTreeChecker.if_r_return if_r_ = null;

        COOLTreeChecker.case_r_return case_r_ = null;

        COOLTreeChecker.new_r_return new_r_ = null;


        try {
            // ./src/COOLTreeChecker.g:166:3: ( ( ^( EXPR_T l= let ) | l= let ) | ( ^( EXPR_T bl= block ) | bl= block ) | ( ^( EXPR_T c= call ) | c= call ) | ( ^( EXPR_T i= INTEGER ) | i= INTEGER ) | ( ^( EXPR_T s= STRING ) | s= STRING ) | ( ^( EXPR_T o= op ) | o= op ) | ( ^( EXPR_T id= ID ) | id= ID ) | ( ^( EXPR_T b= TRUE_ST ) | b= TRUE_ST ) | ( ^( EXPR_T b= FALSE_ST ) | b= FALSE_ST ) | ( ^( EXPR_T w= while_r ) | w= while_r ) | ( ^( EXPR_T if_r_= if_r ) | if_r_= if_r ) | ( ^( EXPR_T case_r_= case_r ) | case_r_= case_r ) | ( ^( EXPR_T new_r_= new_r ) | new_r_= new_r ) )
            int alt18=13;
            alt18 = dfa18.predict(input);
            switch (alt18) {
                case 1 :
                    // ./src/COOLTreeChecker.g:167:3: ( ^( EXPR_T l= let ) | l= let )
                    {
                    // ./src/COOLTreeChecker.g:167:3: ( ^( EXPR_T l= let ) | l= let )
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==EXPR_T) ) {
                        alt5=1;
                    }
                    else if ( (LA5_0==LET_ST) ) {
                        alt5=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 5, 0, input);

                        throw nvae;
                    }
                    switch (alt5) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:167:4: ^( EXPR_T l= let )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr283); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_let_in_expr287);
                            l=let();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:167:22: l= let
                            {
                            pushFollow(FOLLOW_let_in_expr294);
                            l=let();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (l!=null?l.result:null);
                          retval.returnType = (l!=null?l.returnType:null);
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:174:3: ( ^( EXPR_T bl= block ) | bl= block )
                    {
                    // ./src/COOLTreeChecker.g:174:3: ( ^( EXPR_T bl= block ) | bl= block )
                    int alt6=2;
                    int LA6_0 = input.LA(1);

                    if ( (LA6_0==EXPR_T) ) {
                        alt6=1;
                    }
                    else if ( (LA6_0==47) ) {
                        alt6=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 6, 0, input);

                        throw nvae;
                    }
                    switch (alt6) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:174:4: ^( EXPR_T bl= block )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr309); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_block_in_expr313);
                            bl=block();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:174:25: bl= block
                            {
                            pushFollow(FOLLOW_block_in_expr320);
                            bl=block();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (bl!=null?bl.result:null);
                          retval.returnType = (bl!=null?bl.returnType:null);
                        
                    }

                    }
                    break;
                case 3 :
                    // ./src/COOLTreeChecker.g:180:3: ( ^( EXPR_T c= call ) | c= call )
                    {
                    // ./src/COOLTreeChecker.g:180:3: ( ^( EXPR_T c= call ) | c= call )
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==EXPR_T) ) {
                        alt7=1;
                    }
                    else if ( (LA7_0==CALL_T||(LA7_0>=62 && LA7_0<=63)) ) {
                        alt7=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 7, 0, input);

                        throw nvae;
                    }
                    switch (alt7) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:180:4: ^( EXPR_T c= call )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr335); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_call_in_expr339);
                            c=call();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:180:23: c= call
                            {
                            pushFollow(FOLLOW_call_in_expr346);
                            c=call();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (c!=null?c.result:null);
                          retval.returnType = (c!=null?c.returnType:null);
                        
                    }

                    }
                    break;
                case 4 :
                    // ./src/COOLTreeChecker.g:186:3: ( ^( EXPR_T i= INTEGER ) | i= INTEGER )
                    {
                    // ./src/COOLTreeChecker.g:186:3: ( ^( EXPR_T i= INTEGER ) | i= INTEGER )
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==EXPR_T) ) {
                        alt8=1;
                    }
                    else if ( (LA8_0==INTEGER) ) {
                        alt8=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 8, 0, input);

                        throw nvae;
                    }
                    switch (alt8) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:186:4: ^( EXPR_T i= INTEGER )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr361); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            i=(CommonTree)match(input,INTEGER,FOLLOW_INTEGER_in_expr365); if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:186:26: i= INTEGER
                            {
                            i=(CommonTree)match(input,INTEGER,FOLLOW_INTEGER_in_expr372); if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = new int_const((i!=null?i.getLine():0), AbstractTable.inttable.addInt(Integer.parseInt((i!=null?i.getText():null))));
                          retval.returnType = AbstractTable.idtable.addString("Int"); 
                        
                    }

                    }
                    break;
                case 5 :
                    // ./src/COOLTreeChecker.g:192:3: ( ^( EXPR_T s= STRING ) | s= STRING )
                    {
                    // ./src/COOLTreeChecker.g:192:3: ( ^( EXPR_T s= STRING ) | s= STRING )
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==EXPR_T) ) {
                        alt9=1;
                    }
                    else if ( (LA9_0==STRING) ) {
                        alt9=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 9, 0, input);

                        throw nvae;
                    }
                    switch (alt9) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:192:4: ^( EXPR_T s= STRING )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr387); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            s=(CommonTree)match(input,STRING,FOLLOW_STRING_in_expr391); if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:192:25: s= STRING
                            {
                            s=(CommonTree)match(input,STRING,FOLLOW_STRING_in_expr398); if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          // Elimin ghilimelele de la inceputul si sfarsitul string-ului
                          //   "abc" => abc
                          // si apoi normalizez string-ul in functia normalize()
                          String str = (s!=null?s.getText():null);
                          int newLines = 0;
                          
                          for (int __my_private_i = 0 ; __my_private_i < str.length() ; __my_private_i++)
                            if (str.charAt(__my_private_i) == '\n')
                              newLines++;
                              
                          str = normalize(str);
                          
                          if (str == null)
                          {
                            System.err.println("[" + ClassTable.getCurrentFilename() + ":" + (s!=null?s.getLine():0) + "] Invalid formatted string " + (s!=null?s.getText():null) + ".");
                            System.exit(1);
                          }

                          retval.result = new string_const((s!=null?s.getLine():0) + newLines, new StringSymbol(str, str.length(), 0));
                          retval.returnType = AbstractTable.idtable.addString("String");
                        
                    }

                    }
                    break;
                case 6 :
                    // ./src/COOLTreeChecker.g:216:3: ( ^( EXPR_T o= op ) | o= op )
                    {
                    // ./src/COOLTreeChecker.g:216:3: ( ^( EXPR_T o= op ) | o= op )
                    int alt10=2;
                    int LA10_0 = input.LA(1);

                    if ( (LA10_0==EXPR_T) ) {
                        alt10=1;
                    }
                    else if ( ((LA10_0>=NOT_ST && LA10_0<=ISVOID_ST)||(LA10_0>=53 && LA10_0<=61)) ) {
                        alt10=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 10, 0, input);

                        throw nvae;
                    }
                    switch (alt10) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:216:4: ^( EXPR_T o= op )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr413); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_op_in_expr417);
                            o=op();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:216:21: o= op
                            {
                            pushFollow(FOLLOW_op_in_expr424);
                            o=op();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (o!=null?o.result:null);
                          retval.returnType = (o!=null?o.returnType:null);
                        
                    }

                    }
                    break;
                case 7 :
                    // ./src/COOLTreeChecker.g:222:3: ( ^( EXPR_T id= ID ) | id= ID )
                    {
                    // ./src/COOLTreeChecker.g:222:3: ( ^( EXPR_T id= ID ) | id= ID )
                    int alt11=2;
                    int LA11_0 = input.LA(1);

                    if ( (LA11_0==EXPR_T) ) {
                        alt11=1;
                    }
                    else if ( (LA11_0==ID) ) {
                        alt11=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 11, 0, input);

                        throw nvae;
                    }
                    switch (alt11) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:222:4: ^( EXPR_T id= ID )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr439); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            id=(CommonTree)match(input,ID,FOLLOW_ID_in_expr443); if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:222:22: id= ID
                            {
                            id=(CommonTree)match(input,ID,FOLLOW_ID_in_expr450); if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = new object((id!=null?id.getLine():0), AbstractTable.idtable.addString((id!=null?id.getText():null))); 
                        
                    }

                    }
                    break;
                case 8 :
                    // ./src/COOLTreeChecker.g:227:3: ( ^( EXPR_T b= TRUE_ST ) | b= TRUE_ST )
                    {
                    // ./src/COOLTreeChecker.g:227:3: ( ^( EXPR_T b= TRUE_ST ) | b= TRUE_ST )
                    int alt12=2;
                    int LA12_0 = input.LA(1);

                    if ( (LA12_0==EXPR_T) ) {
                        alt12=1;
                    }
                    else if ( (LA12_0==TRUE_ST) ) {
                        alt12=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 12, 0, input);

                        throw nvae;
                    }
                    switch (alt12) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:227:4: ^( EXPR_T b= TRUE_ST )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr465); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            b=(CommonTree)match(input,TRUE_ST,FOLLOW_TRUE_ST_in_expr469); if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:227:26: b= TRUE_ST
                            {
                            b=(CommonTree)match(input,TRUE_ST,FOLLOW_TRUE_ST_in_expr476); if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = new bool_const((b!=null?b.getLine():0), true);
                          retval.returnType = AbstractTable.idtable.addString("Bool");
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;
                case 9 :
                    // ./src/COOLTreeChecker.g:234:3: ( ^( EXPR_T b= FALSE_ST ) | b= FALSE_ST )
                    {
                    // ./src/COOLTreeChecker.g:234:3: ( ^( EXPR_T b= FALSE_ST ) | b= FALSE_ST )
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==EXPR_T) ) {
                        alt13=1;
                    }
                    else if ( (LA13_0==FALSE_ST) ) {
                        alt13=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 13, 0, input);

                        throw nvae;
                    }
                    switch (alt13) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:234:4: ^( EXPR_T b= FALSE_ST )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr491); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            b=(CommonTree)match(input,FALSE_ST,FOLLOW_FALSE_ST_in_expr495); if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:234:27: b= FALSE_ST
                            {
                            b=(CommonTree)match(input,FALSE_ST,FOLLOW_FALSE_ST_in_expr502); if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = new bool_const((b!=null?b.getLine():0), false);
                          retval.returnType = AbstractTable.idtable.addString("Bool");
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;
                case 10 :
                    // ./src/COOLTreeChecker.g:241:3: ( ^( EXPR_T w= while_r ) | w= while_r )
                    {
                    // ./src/COOLTreeChecker.g:241:3: ( ^( EXPR_T w= while_r ) | w= while_r )
                    int alt14=2;
                    int LA14_0 = input.LA(1);

                    if ( (LA14_0==EXPR_T) ) {
                        alt14=1;
                    }
                    else if ( (LA14_0==WHILE_ST) ) {
                        alt14=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 14, 0, input);

                        throw nvae;
                    }
                    switch (alt14) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:241:4: ^( EXPR_T w= while_r )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr517); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_while_r_in_expr521);
                            w=while_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:241:26: w= while_r
                            {
                            pushFollow(FOLLOW_while_r_in_expr528);
                            w=while_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (w!=null?w.result:null);
                          retval.returnType = (w!=null?w.returnType:null);
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;
                case 11 :
                    // ./src/COOLTreeChecker.g:248:3: ( ^( EXPR_T if_r_= if_r ) | if_r_= if_r )
                    {
                    // ./src/COOLTreeChecker.g:248:3: ( ^( EXPR_T if_r_= if_r ) | if_r_= if_r )
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==EXPR_T) ) {
                        alt15=1;
                    }
                    else if ( (LA15_0==IF_ST) ) {
                        alt15=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 15, 0, input);

                        throw nvae;
                    }
                    switch (alt15) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:248:4: ^( EXPR_T if_r_= if_r )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr543); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_if_r_in_expr547);
                            if_r_=if_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:248:27: if_r_= if_r
                            {
                            pushFollow(FOLLOW_if_r_in_expr554);
                            if_r_=if_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (if_r_!=null?if_r_.result:null);
                          retval.returnType = (if_r_!=null?if_r_.returnType:null);
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;
                case 12 :
                    // ./src/COOLTreeChecker.g:255:3: ( ^( EXPR_T case_r_= case_r ) | case_r_= case_r )
                    {
                    // ./src/COOLTreeChecker.g:255:3: ( ^( EXPR_T case_r_= case_r ) | case_r_= case_r )
                    int alt16=2;
                    int LA16_0 = input.LA(1);

                    if ( (LA16_0==EXPR_T) ) {
                        alt16=1;
                    }
                    else if ( (LA16_0==CASE_ST) ) {
                        alt16=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 16, 0, input);

                        throw nvae;
                    }
                    switch (alt16) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:255:4: ^( EXPR_T case_r_= case_r )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr569); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_case_r_in_expr573);
                            case_r_=case_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:255:31: case_r_= case_r
                            {
                            pushFollow(FOLLOW_case_r_in_expr580);
                            case_r_=case_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (case_r_!=null?case_r_.result:null);
                          retval.returnType = (case_r_!=null?case_r_.returnType:null);
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;
                case 13 :
                    // ./src/COOLTreeChecker.g:262:3: ( ^( EXPR_T new_r_= new_r ) | new_r_= new_r )
                    {
                    // ./src/COOLTreeChecker.g:262:3: ( ^( EXPR_T new_r_= new_r ) | new_r_= new_r )
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==EXPR_T) ) {
                        alt17=1;
                    }
                    else if ( (LA17_0==NEW_ST) ) {
                        alt17=2;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }
                    switch (alt17) {
                        case 1 :
                            // ./src/COOLTreeChecker.g:262:4: ^( EXPR_T new_r_= new_r )
                            {
                            match(input,EXPR_T,FOLLOW_EXPR_T_in_expr595); if (state.failed) return retval;

                            match(input, Token.DOWN, null); if (state.failed) return retval;
                            pushFollow(FOLLOW_new_r_in_expr599);
                            new_r_=new_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            match(input, Token.UP, null); if (state.failed) return retval;

                            }
                            break;
                        case 2 :
                            // ./src/COOLTreeChecker.g:262:29: new_r_= new_r
                            {
                            pushFollow(FOLLOW_new_r_in_expr606);
                            new_r_=new_r();

                            state._fsp--;
                            if (state.failed) return retval;

                            }
                            break;

                    }

                    if ( state.backtracking==0 ) {

                          retval.result = (new_r_!=null?new_r_.result:null);
                          retval.returnType = (new_r_!=null?new_r_.returnType:null);
                          retval.result.set_type(retval.returnType);
                        
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "expr"


    // $ANTLR start "formals"
    // ./src/COOLTreeChecker.g:270:1: formals returns [Formals result] : ^( FORMALS_T ( formal )* ) ;
    public final Formals formals() throws RecognitionException {
        Formals result = null;

        CommonTree FORMALS_T13=null;
        formal formal14 = null;


        try {
            // ./src/COOLTreeChecker.g:271:3: ( ^( FORMALS_T ( formal )* ) )
            // ./src/COOLTreeChecker.g:272:3: ^( FORMALS_T ( formal )* )
            {
            FORMALS_T13=(CommonTree)match(input,FORMALS_T,FOLLOW_FORMALS_T_in_formals631); if (state.failed) return result;

            if ( state.backtracking==0 ) {
               result = new Formals((FORMALS_T13!=null?FORMALS_T13.getLine():0)); 
            }

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return result;
                // ./src/COOLTreeChecker.g:273:5: ( formal )*
                loop19:
                do {
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==TYPE_ID) ) {
                        alt19=1;
                    }


                    switch (alt19) {
                	case 1 :
                	    // ./src/COOLTreeChecker.g:273:6: formal
                	    {
                	    pushFollow(FOLLOW_formal_in_formals640);
                	    formal14=formal();

                	    state._fsp--;
                	    if (state.failed) return result;
                	    if ( state.backtracking==0 ) {
                	       result.appendElement(formal14); 
                	    }

                	    }
                	    break;

                	default :
                	    break loop19;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return result;
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end "formals"


    // $ANTLR start "formal"
    // ./src/COOLTreeChecker.g:279:1: formal returns [formal result] : ^( TYPE_ID name= ID type= TYPE ) ;
    public final formal formal() throws RecognitionException {
        formal result = null;

        CommonTree name=null;
        CommonTree type=null;
        CommonTree TYPE_ID15=null;

        try {
            // ./src/COOLTreeChecker.g:280:3: ( ^( TYPE_ID name= ID type= TYPE ) )
            // ./src/COOLTreeChecker.g:281:3: ^( TYPE_ID name= ID type= TYPE )
            {
            TYPE_ID15=(CommonTree)match(input,TYPE_ID,FOLLOW_TYPE_ID_in_formal680); if (state.failed) return result;

            match(input, Token.DOWN, null); if (state.failed) return result;
            name=(CommonTree)match(input,ID,FOLLOW_ID_in_formal684); if (state.failed) return result;
            type=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_formal688); if (state.failed) return result;

            match(input, Token.UP, null); if (state.failed) return result;
            if ( state.backtracking==0 ) {

                  AbstractSymbol __name = AbstractTable.idtable.addString((name!=null?name.getText():null));
                  AbstractSymbol __type = AbstractTable.idtable.addString((type!=null?type.getText():null));
                  
                  result = new formal((TYPE_ID15!=null?TYPE_ID15.getLine():0), __name, __type);
                
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return result;
    }
    // $ANTLR end "formal"

    public static class adapt_id_integer_return extends TreeRuleReturnScope {
        public String result;
        public String type;
    };

    // $ANTLR start "adapt_id_integer"
    // ./src/COOLTreeChecker.g:290:1: adapt_id_integer returns [String result, String type] : ( INTEGER | ID );
    public final COOLTreeChecker.adapt_id_integer_return adapt_id_integer() throws RecognitionException {
        COOLTreeChecker.adapt_id_integer_return retval = new COOLTreeChecker.adapt_id_integer_return();
        retval.start = input.LT(1);

        CommonTree INTEGER16=null;
        CommonTree ID17=null;

        try {
            // ./src/COOLTreeChecker.g:291:3: ( INTEGER | ID )
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( (LA20_0==INTEGER) ) {
                alt20=1;
            }
            else if ( (LA20_0==ID) ) {
                alt20=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 20, 0, input);

                throw nvae;
            }
            switch (alt20) {
                case 1 :
                    // ./src/COOLTreeChecker.g:292:3: INTEGER
                    {
                    INTEGER16=(CommonTree)match(input,INTEGER,FOLLOW_INTEGER_in_adapt_id_integer712); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                       retval.result = (INTEGER16!=null?INTEGER16.getText():null); retval.type = "Integer"; 
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:294:3: ID
                    {
                    ID17=(CommonTree)match(input,ID,FOLLOW_ID_in_adapt_id_integer722); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {
                       retval.result = (ID17!=null?ID17.getText():null); retval.type = "Id"; 
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "adapt_id_integer"

    public static class op_return extends TreeRuleReturnScope {
        public Expression result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "op"
    // ./src/COOLTreeChecker.g:297:1: op returns [Expression result, AbstractSymbol returnType] : ( ( ^( op_bin expr expr ) )=> ^(o= op_bin e1= expr e2= expr ) | ^(o= op_bin p1= adapt_id_integer p2= adapt_id_integer ) | ^(e= '~' expr ) | ^( NOT_ST expr ) | ^( ISVOID_ST expr ) | ^(assignStr= '<-' ID expr ) );
    public final COOLTreeChecker.op_return op() throws RecognitionException {
        COOLTreeChecker.op_return retval = new COOLTreeChecker.op_return();
        retval.start = input.LT(1);

        CommonTree e=null;
        CommonTree assignStr=null;
        CommonTree NOT_ST19=null;
        CommonTree ISVOID_ST21=null;
        CommonTree ID23=null;
        COOLTreeChecker.op_bin_return o = null;

        COOLTreeChecker.expr_return e1 = null;

        COOLTreeChecker.expr_return e2 = null;

        COOLTreeChecker.adapt_id_integer_return p1 = null;

        COOLTreeChecker.adapt_id_integer_return p2 = null;

        COOLTreeChecker.expr_return expr18 = null;

        COOLTreeChecker.expr_return expr20 = null;

        COOLTreeChecker.expr_return expr22 = null;

        COOLTreeChecker.expr_return expr24 = null;


        try {
            // ./src/COOLTreeChecker.g:298:3: ( ( ^( op_bin expr expr ) )=> ^(o= op_bin e1= expr e2= expr ) | ^(o= op_bin p1= adapt_id_integer p2= adapt_id_integer ) | ^(e= '~' expr ) | ^( NOT_ST expr ) | ^( ISVOID_ST expr ) | ^(assignStr= '<-' ID expr ) )
            int alt21=6;
            alt21 = dfa21.predict(input);
            switch (alt21) {
                case 1 :
                    // ./src/COOLTreeChecker.g:299:3: ( ^( op_bin expr expr ) )=> ^(o= op_bin e1= expr e2= expr )
                    {
                    pushFollow(FOLLOW_op_bin_in_op765);
                    o=op_bin();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_op771);
                    e1=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_op777);
                    e2=expr();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          retval.result = applyOp((o!=null?o.text:null), (o!=null?o.line:0), (e1!=null?e1.result:null), (e2!=null?e2.result:null));
                        
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:304:3: ^(o= op_bin p1= adapt_id_integer p2= adapt_id_integer )
                    {
                    pushFollow(FOLLOW_op_bin_in_op795);
                    o=op_bin();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_adapt_id_integer_in_op801);
                    p1=adapt_id_integer();

                    state._fsp--;
                    if (state.failed) return retval;
                    pushFollow(FOLLOW_adapt_id_integer_in_op807);
                    p2=adapt_id_integer();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          Expression __name = null;
                          Expression __expr = null;

                          if ((p1!=null?p1.type:null).equals("Integer"))
                            __name = new int_const((o!=null?o.line:0), AbstractTable.inttable.addInt(Integer.parseInt((p1!=null?p1.result:null))));
                          else if ((p1!=null?p1.type:null).equals("Id"))
                            __name = new object((o!=null?o.line:0), AbstractTable.idtable.addString((p1!=null?p1.result:null)));

                          if ((p2!=null?p2.type:null).equals("Integer"))
                            __expr = new int_const((o!=null?o.line:0), AbstractTable.inttable.addInt(Integer.parseInt((p2!=null?p2.result:null))));
                          else if ((p2!=null?p2.type:null).equals("Id"))
                            __expr = new object((o!=null?o.line:0), AbstractTable.idtable.addString((p2!=null?p2.result:null)));

                          applyOp((o!=null?o.text:null), (o!=null?o.line:0), __name, __expr);
                        
                    }

                    }
                    break;
                case 3 :
                    // ./src/COOLTreeChecker.g:322:3: ^(e= '~' expr )
                    {
                    e=(CommonTree)match(input,61,FOLLOW_61_in_op823); if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_op825);
                    expr18=expr();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          retval.result = new neg((e!=null?e.getLine():0), (expr18!=null?expr18.result:null));
                          retval.returnType = (expr18!=null?expr18.returnType:null);
                        
                    }

                    }
                    break;
                case 4 :
                    // ./src/COOLTreeChecker.g:328:3: ^( NOT_ST expr )
                    {
                    NOT_ST19=(CommonTree)match(input,NOT_ST,FOLLOW_NOT_ST_in_op839); if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_op841);
                    expr20=expr();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          retval.result = new comp((NOT_ST19!=null?NOT_ST19.getLine():0), (expr20!=null?expr20.result:null));
                          retval.returnType = (expr20!=null?expr20.returnType:null);
                        
                    }

                    }
                    break;
                case 5 :
                    // ./src/COOLTreeChecker.g:334:3: ^( ISVOID_ST expr )
                    {
                    ISVOID_ST21=(CommonTree)match(input,ISVOID_ST,FOLLOW_ISVOID_ST_in_op855); if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_op857);
                    expr22=expr();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          retval.result = new isvoid((ISVOID_ST21!=null?ISVOID_ST21.getLine():0), (expr22!=null?expr22.result:null));
                          retval.returnType = (expr22!=null?expr22.returnType:null);
                        
                    }

                    }
                    break;
                case 6 :
                    // ./src/COOLTreeChecker.g:340:3: ^(assignStr= '<-' ID expr )
                    {
                    assignStr=(CommonTree)match(input,53,FOLLOW_53_in_op873); if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    ID23=(CommonTree)match(input,ID,FOLLOW_ID_in_op875); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_op877);
                    expr24=expr();

                    state._fsp--;
                    if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          retval.result = new assign((assignStr!=null?assignStr.getLine():0), AbstractTable.idtable.addString((ID23!=null?ID23.getText():null)), (expr24!=null?expr24.result:null));
                        
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "op"

    public static class op_bin_return extends TreeRuleReturnScope {
        public String text;
        public int line;
    };

    // $ANTLR start "op_bin"
    // ./src/COOLTreeChecker.g:346:1: op_bin returns [String text, int line] : ( ( '<=' )=>e= '<=' | e= ( '+' | '-' | '*' | '/' | '<' | '=' ) );
    public final COOLTreeChecker.op_bin_return op_bin() throws RecognitionException {
        COOLTreeChecker.op_bin_return retval = new COOLTreeChecker.op_bin_return();
        retval.start = input.LT(1);

        CommonTree e=null;

        try {
            // ./src/COOLTreeChecker.g:347:3: ( ( '<=' )=>e= '<=' | e= ( '+' | '-' | '*' | '/' | '<' | '=' ) )
            int alt22=2;
            int LA22_0 = input.LA(1);

            if ( (LA22_0==54) && (synpred2_COOLTreeChecker())) {
                alt22=1;
            }
            else if ( ((LA22_0>=55 && LA22_0<=60)) ) {
                alt22=2;
            }
            else {
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 22, 0, input);

                throw nvae;
            }
            switch (alt22) {
                case 1 :
                    // ./src/COOLTreeChecker.g:348:3: ( '<=' )=>e= '<='
                    {
                    e=(CommonTree)match(input,54,FOLLOW_54_in_op_bin911); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          retval.text = (e!=null?e.getText():null);
                          retval.line = (e!=null?e.getLine():0);
                        
                    }

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:354:3: e= ( '+' | '-' | '*' | '/' | '<' | '=' )
                    {
                    e=(CommonTree)input.LT(1);
                    if ( (input.LA(1)>=55 && input.LA(1)<=60) ) {
                        input.consume();
                        state.errorRecovery=false;state.failed=false;
                    }
                    else {
                        if (state.backtracking>0) {state.failed=true; return retval;}
                        MismatchedSetException mse = new MismatchedSetException(null,input);
                        throw mse;
                    }

                    if ( state.backtracking==0 ) {

                          retval.text = (e!=null?e.getText():null);
                          retval.line = (e!=null?e.getLine():0);
                        
                    }

                    }
                    break;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "op_bin"

    public static class block_return extends TreeRuleReturnScope {
        public block result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "block"
    // ./src/COOLTreeChecker.g:361:1: block returns [block result, AbstractSymbol returnType] : ^(p= '{' ( expr )* ) ;
    public final COOLTreeChecker.block_return block() throws RecognitionException {
        COOLTreeChecker.block_return retval = new COOLTreeChecker.block_return();
        retval.start = input.LT(1);

        CommonTree p=null;
        COOLTreeChecker.expr_return expr25 = null;



          Expressions exprs = null;

        try {
            // ./src/COOLTreeChecker.g:365:3: ( ^(p= '{' ( expr )* ) )
            // ./src/COOLTreeChecker.g:366:3: ^(p= '{' ( expr )* )
            {
            p=(CommonTree)match(input,47,FOLLOW_47_in_block980); if (state.failed) return retval;

            if ( state.backtracking==0 ) {
               exprs = new Expressions((p!=null?p.getLine():0)); retval.result = null; retval.result = new block((p!=null?p.getLine():0), exprs); 
            }

            if ( input.LA(1)==Token.DOWN ) {
                match(input, Token.DOWN, null); if (state.failed) return retval;
                // ./src/COOLTreeChecker.g:367:5: ( expr )*
                loop23:
                do {
                    int alt23=2;
                    int LA23_0 = input.LA(1);

                    if ( (LA23_0==CALL_T||LA23_0==EXPR_T||(LA23_0>=ID && LA23_0<=IF_ST)||LA23_0==WHILE_ST||LA23_0==CASE_ST||LA23_0==LET_ST||LA23_0==47||(LA23_0>=53 && LA23_0<=63)) ) {
                        alt23=1;
                    }


                    switch (alt23) {
                	case 1 :
                	    // ./src/COOLTreeChecker.g:367:6: expr
                	    {
                	    pushFollow(FOLLOW_expr_in_block990);
                	    expr25=expr();

                	    state._fsp--;
                	    if (state.failed) return retval;
                	    if ( state.backtracking==0 ) {
                	       exprs.appendElement((expr25!=null?expr25.result:null)); retval.returnType = (expr25!=null?expr25.returnType:null); 
                	    }

                	    }
                	    break;

                	default :
                	    break loop23;
                    }
                } while (true);


                match(input, Token.UP, null); if (state.failed) return retval;
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "block"

    public static class call_return extends TreeRuleReturnScope {
        public Expression result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "call"
    // ./src/COOLTreeChecker.g:371:1: call returns [Expression result, AbstractSymbol returnType] : ( ^( CALL_T ID (e2= expr )* ) | ^(aux= '.' e1= expr ID (e2= expr )* ) | ^(aux= '@' expr TYPE ) );
    public final COOLTreeChecker.call_return call() throws RecognitionException {
        COOLTreeChecker.call_return retval = new COOLTreeChecker.call_return();
        retval.start = input.LT(1);

        CommonTree aux=null;
        CommonTree CALL_T26=null;
        CommonTree ID27=null;
        CommonTree ID28=null;
        CommonTree TYPE30=null;
        COOLTreeChecker.expr_return e2 = null;

        COOLTreeChecker.expr_return e1 = null;

        COOLTreeChecker.expr_return expr29 = null;



          Expressions exprs = null;
          level++;

        try {
            // ./src/COOLTreeChecker.g:379:3: ( ^( CALL_T ID (e2= expr )* ) | ^(aux= '.' e1= expr ID (e2= expr )* ) | ^(aux= '@' expr TYPE ) )
            int alt26=3;
            switch ( input.LA(1) ) {
            case CALL_T:
                {
                alt26=1;
                }
                break;
            case 63:
                {
                alt26=2;
                }
                break;
            case 62:
                {
                alt26=3;
                }
                break;
            default:
                if (state.backtracking>0) {state.failed=true; return retval;}
                NoViableAltException nvae =
                    new NoViableAltException("", 26, 0, input);

                throw nvae;
            }

            switch (alt26) {
                case 1 :
                    // ./src/COOLTreeChecker.g:380:3: ^( CALL_T ID (e2= expr )* )
                    {
                    CALL_T26=(CommonTree)match(input,CALL_T,FOLLOW_CALL_T_in_call1029); if (state.failed) return retval;

                    if ( state.backtracking==0 ) {
                       exprs = new Expressions((CALL_T26!=null?CALL_T26.getLine():0)); 
                    }

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    ID27=(CommonTree)match(input,ID,FOLLOW_ID_in_call1038); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                                Expression self_type = new object((ID27!=null?ID27.getLine():0), AbstractTable.idtable.addString("self"));
                                self_type.set_type(AbstractTable.idtable.addString("SELF_TYPE"));
                                retval.result = new dispatch((CALL_T26!=null?CALL_T26.getLine():0), self_type, AbstractTable.idtable.addString((ID27!=null?ID27.getText():null)), exprs); 
                             
                    }
                    // ./src/COOLTreeChecker.g:386:5: (e2= expr )*
                    loop24:
                    do {
                        int alt24=2;
                        int LA24_0 = input.LA(1);

                        if ( (LA24_0==CALL_T||LA24_0==EXPR_T||(LA24_0>=ID && LA24_0<=IF_ST)||LA24_0==WHILE_ST||LA24_0==CASE_ST||LA24_0==LET_ST||LA24_0==47||(LA24_0>=53 && LA24_0<=63)) ) {
                            alt24=1;
                        }


                        switch (alt24) {
                    	case 1 :
                    	    // ./src/COOLTreeChecker.g:386:6: e2= expr
                    	    {
                    	    pushFollow(FOLLOW_expr_in_call1049);
                    	    e2=expr();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	       exprs.appendElement((e2!=null?e2.result:null)); retval.returnType = (e2!=null?e2.returnType:null); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop24;
                        }
                    } while (true);


                    match(input, Token.UP, null); if (state.failed) return retval;

                    }
                    break;
                case 2 :
                    // ./src/COOLTreeChecker.g:389:3: ^(aux= '.' e1= expr ID (e2= expr )* )
                    {
                    aux=(CommonTree)match(input,63,FOLLOW_63_in_call1069); if (state.failed) return retval;

                    if ( state.backtracking==0 ) {
                       exprs = new Expressions((aux!=null?aux.getLine():0)); 
                    }

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_call1079);
                    e1=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    ID28=(CommonTree)match(input,ID,FOLLOW_ID_in_call1081); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                              if (level != static_dispatchLevel - 1)
                              {
                      	        retval.result = new dispatch((aux!=null?aux.getLine():0), (e1!=null?e1.result:null), AbstractTable.idtable.addString((ID28!=null?ID28.getText():null)),
                      	          exprs);
                      	      }
                          
                    }
                    // ./src/COOLTreeChecker.g:398:5: (e2= expr )*
                    loop25:
                    do {
                        int alt25=2;
                        int LA25_0 = input.LA(1);

                        if ( (LA25_0==CALL_T||LA25_0==EXPR_T||(LA25_0>=ID && LA25_0<=IF_ST)||LA25_0==WHILE_ST||LA25_0==CASE_ST||LA25_0==LET_ST||LA25_0==47||(LA25_0>=53 && LA25_0<=63)) ) {
                            alt25=1;
                        }


                        switch (alt25) {
                    	case 1 :
                    	    // ./src/COOLTreeChecker.g:398:6: e2= expr
                    	    {
                    	    pushFollow(FOLLOW_expr_in_call1096);
                    	    e2=expr();

                    	    state._fsp--;
                    	    if (state.failed) return retval;
                    	    if ( state.backtracking==0 ) {
                    	       exprs.appendElement((e2!=null?e2.result:null)); 
                    	    }

                    	    }
                    	    break;

                    	default :
                    	    break loop25;
                        }
                    } while (true);


                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                              // Atasez de parinte dispatch-ul static
                              if (level == static_dispatchLevel - 1)
                              {
                                retval.result = new static_dispatch(static_dispatchLine, static_dispatchExpr, static_dispatchObj,
                                  AbstractTable.idtable.addString((ID28!=null?ID28.getText():null)), exprs);
                                static_dispatchLevel = -1;
                                static_dispatchLine = -1;
                                static_dispatchExpr = null;
                                static_dispatchObj = null;
                              }
                          
                    }

                    }
                    break;
                case 3 :
                    // ./src/COOLTreeChecker.g:413:3: ^(aux= '@' expr TYPE )
                    {
                    aux=(CommonTree)match(input,62,FOLLOW_62_in_call1123); if (state.failed) return retval;

                    match(input, Token.DOWN, null); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_call1125);
                    expr29=expr();

                    state._fsp--;
                    if (state.failed) return retval;
                    TYPE30=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_call1127); if (state.failed) return retval;

                    match(input, Token.UP, null); if (state.failed) return retval;
                    if ( state.backtracking==0 ) {

                          static_dispatchExpr = (expr29!=null?expr29.result:null);
                          static_dispatchObj = AbstractTable.idtable.addString((TYPE30!=null?TYPE30.getText():null));
                          static_dispatchLine = (aux!=null?aux.getLine():0);
                          static_dispatchLevel = level;
                        
                    }

                    }
                    break;

            }
            if ( state.backtracking==0 ) {

                level--;

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "call"

    public static class let_return extends TreeRuleReturnScope {
        public let result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "let"
    // ./src/COOLTreeChecker.g:422:1: let returns [let result, AbstractSymbol returnType] : ^( LET_ST id= ID type= TYPE ( '<-' e1= expr )? ( ',' id_= ID type_= TYPE ( '<-' expr_= expr )? )* e2= expr ) ;
    public final COOLTreeChecker.let_return let() throws RecognitionException {
        COOLTreeChecker.let_return retval = new COOLTreeChecker.let_return();
        retval.start = input.LT(1);

        CommonTree id=null;
        CommonTree type=null;
        CommonTree id_=null;
        CommonTree type_=null;
        COOLTreeChecker.expr_return e1 = null;

        COOLTreeChecker.expr_return expr_ = null;

        COOLTreeChecker.expr_return e2 = null;



          int line = -1;
          LinkedList queue = new LinkedList();
          Expression lastExpr = null;
          Expression firstExpr = null;
          String firstId = null, firstType = null;
          Expression my_expr = null, my_aux_expr = null;
          String my_id = null, my_type = null;
          Integer my_line = null;

        try {
            // ./src/COOLTreeChecker.g:485:3: ( ^( LET_ST id= ID type= TYPE ( '<-' e1= expr )? ( ',' id_= ID type_= TYPE ( '<-' expr_= expr )? )* e2= expr ) )
            // ./src/COOLTreeChecker.g:486:3: ^( LET_ST id= ID type= TYPE ( '<-' e1= expr )? ( ',' id_= ID type_= TYPE ( '<-' expr_= expr )? )* e2= expr )
            {
            match(input,LET_ST,FOLLOW_LET_ST_in_let1164); if (state.failed) return retval;

            match(input, Token.DOWN, null); if (state.failed) return retval;
            id=(CommonTree)match(input,ID,FOLLOW_ID_in_let1168); if (state.failed) return retval;
            type=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_let1172); if (state.failed) return retval;
            // ./src/COOLTreeChecker.g:486:28: ( '<-' e1= expr )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( (LA27_0==53) ) {
                int LA27_1 = input.LA(2);

                if ( (LA27_1==CALL_T||LA27_1==EXPR_T||(LA27_1>=ID && LA27_1<=IF_ST)||LA27_1==WHILE_ST||LA27_1==CASE_ST||LA27_1==LET_ST||LA27_1==47||(LA27_1>=53 && LA27_1<=63)) ) {
                    alt27=1;
                }
            }
            switch (alt27) {
                case 1 :
                    // ./src/COOLTreeChecker.g:486:29: '<-' e1= expr
                    {
                    match(input,53,FOLLOW_53_in_let1175); if (state.failed) return retval;
                    pushFollow(FOLLOW_expr_in_let1179);
                    e1=expr();

                    state._fsp--;
                    if (state.failed) return retval;

                    }
                    break;

            }

            // ./src/COOLTreeChecker.g:486:44: ( ',' id_= ID type_= TYPE ( '<-' expr_= expr )? )*
            loop29:
            do {
                int alt29=2;
                int LA29_0 = input.LA(1);

                if ( (LA29_0==50) ) {
                    alt29=1;
                }


                switch (alt29) {
            	case 1 :
            	    // ./src/COOLTreeChecker.g:486:45: ',' id_= ID type_= TYPE ( '<-' expr_= expr )?
            	    {
            	    match(input,50,FOLLOW_50_in_let1184); if (state.failed) return retval;
            	    id_=(CommonTree)match(input,ID,FOLLOW_ID_in_let1188); if (state.failed) return retval;
            	    type_=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_let1192); if (state.failed) return retval;
            	    // ./src/COOLTreeChecker.g:486:67: ( '<-' expr_= expr )?
            	    int alt28=2;
            	    int LA28_0 = input.LA(1);

            	    if ( (LA28_0==53) ) {
            	        int LA28_1 = input.LA(2);

            	        if ( (LA28_1==CALL_T||LA28_1==EXPR_T||(LA28_1>=ID && LA28_1<=IF_ST)||LA28_1==WHILE_ST||LA28_1==CASE_ST||LA28_1==LET_ST||LA28_1==47||(LA28_1>=53 && LA28_1<=63)) ) {
            	            alt28=1;
            	        }
            	    }
            	    switch (alt28) {
            	        case 1 :
            	            // ./src/COOLTreeChecker.g:486:68: '<-' expr_= expr
            	            {
            	            match(input,53,FOLLOW_53_in_let1195); if (state.failed) return retval;
            	            pushFollow(FOLLOW_expr_in_let1199);
            	            expr_=expr();

            	            state._fsp--;
            	            if (state.failed) return retval;

            	            }
            	            break;

            	    }

            	    if ( state.backtracking==0 ) {

            	            if ((id_!=null?id_.getLine():0) == 277)
            	            {
            	              System.out.println("askjdal");
            	              System.exit(0);
            	            }
            	             
            	            queue.add(new Integer((id_!=null?id_.getLine():0)));
            	            queue.add((id_!=null?id_.getText():null));
            	            queue.add((type_!=null?type_.getText():null));
            	            if (expr_ != null)
            	              queue.add((expr_!=null?expr_.result:null));
            	            queue.add(null);
            	          
            	    }

            	    }
            	    break;

            	default :
            	    break loop29;
                }
            } while (true);

            pushFollow(FOLLOW_expr_in_let1216);
            e2=expr();

            state._fsp--;
            if (state.failed) return retval;

            match(input, Token.UP, null); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

                  line = (id!=null?id.getLine():0);
                  lastExpr = (e2!=null?e2.result:null);
                  firstId = (id!=null?id.getText():null);
                  firstType = (type!=null?type.getText():null);
                  firstExpr = (e1!=null?e1.result:null);
                
            }

            }

            if ( state.backtracking==0 ) {

                Object[] buffer = new Object[4];
                Object it = null;
                
                if (queue.size() > 0)
                {
              	  queue.removeLast();
              	  
              	  while(queue.size() > 0)
              	  {
              	    int counter = 0;
              		  // Fac pop() la ultimul "let" din lista
              		  while(queue.size() > 0)
              		  {
              		    it = queue.removeLast();
              		    if (it == null)
              		     break;
              		    buffer[counter++] = it;
              		  }
              		  
              		  if (counter == 3)
              		  {
              		    my_type = (String) buffer[0];
              		    my_id = (String) buffer[1];
              		    my_line = (Integer) buffer[2];
              		    
              	      my_aux_expr = new let(my_line, AbstractTable.idtable.addString(my_id),
              	        AbstractTable.idtable.addString(my_type), new no_expr(0), lastExpr);  
              		  }
              		  else if (counter == 4)
              		  {
              		    my_expr = (Expression) buffer[0];
              		    my_type = (String) buffer[1];
              		    my_id = (String) buffer[2];
              		    my_line = (Integer) buffer[3];
              		    
              	      my_aux_expr = new let(my_line, AbstractTable.idtable.addString(my_id),
              	       AbstractTable.idtable.addString(my_type), my_expr, lastExpr);
              		  }
              		  lastExpr = my_aux_expr;
              	  }
                }

                if (firstExpr == null)
                  firstExpr = new no_expr(0);
                  
                if (lastExpr == null)
                  lastExpr = new no_expr(0);
                  
                retval.result = new let(line, AbstractTable.idtable.addString(firstId),
              	 AbstractTable.idtable.addString(firstType), firstExpr, lastExpr);

            }
        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "let"

    public static class while_r_return extends TreeRuleReturnScope {
        public loop result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "while_r"
    // ./src/COOLTreeChecker.g:511:1: while_r returns [loop result, AbstractSymbol returnType] : ^( WHILE_ST e1= expr e2= expr ) ;
    public final COOLTreeChecker.while_r_return while_r() throws RecognitionException {
        COOLTreeChecker.while_r_return retval = new COOLTreeChecker.while_r_return();
        retval.start = input.LT(1);

        CommonTree WHILE_ST31=null;
        COOLTreeChecker.expr_return e1 = null;

        COOLTreeChecker.expr_return e2 = null;


        try {
            // ./src/COOLTreeChecker.g:512:3: ( ^( WHILE_ST e1= expr e2= expr ) )
            // ./src/COOLTreeChecker.g:513:3: ^( WHILE_ST e1= expr e2= expr )
            {
            WHILE_ST31=(CommonTree)match(input,WHILE_ST,FOLLOW_WHILE_ST_in_while_r1241); if (state.failed) return retval;

            match(input, Token.DOWN, null); if (state.failed) return retval;
            pushFollow(FOLLOW_expr_in_while_r1245);
            e1=expr();

            state._fsp--;
            if (state.failed) return retval;
            pushFollow(FOLLOW_expr_in_while_r1249);
            e2=expr();

            state._fsp--;
            if (state.failed) return retval;

            match(input, Token.UP, null); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

                  retval.result = new loop((WHILE_ST31!=null?WHILE_ST31.getLine():0), (e1!=null?e1.result:null), (e2!=null?e2.result:null));
                  retval.returnType = (e2!=null?e2.returnType:null);
                
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "while_r"

    public static class if_r_return extends TreeRuleReturnScope {
        public cond result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "if_r"
    // ./src/COOLTreeChecker.g:520:1: if_r returns [cond result, AbstractSymbol returnType] : ^( IF_ST e1= expr e2= expr e3= expr ) ;
    public final COOLTreeChecker.if_r_return if_r() throws RecognitionException {
        COOLTreeChecker.if_r_return retval = new COOLTreeChecker.if_r_return();
        retval.start = input.LT(1);

        CommonTree IF_ST32=null;
        COOLTreeChecker.expr_return e1 = null;

        COOLTreeChecker.expr_return e2 = null;

        COOLTreeChecker.expr_return e3 = null;


        try {
            // ./src/COOLTreeChecker.g:521:3: ( ^( IF_ST e1= expr e2= expr e3= expr ) )
            // ./src/COOLTreeChecker.g:522:3: ^( IF_ST e1= expr e2= expr e3= expr )
            {
            IF_ST32=(CommonTree)match(input,IF_ST,FOLLOW_IF_ST_in_if_r1274); if (state.failed) return retval;

            match(input, Token.DOWN, null); if (state.failed) return retval;
            pushFollow(FOLLOW_expr_in_if_r1278);
            e1=expr();

            state._fsp--;
            if (state.failed) return retval;
            pushFollow(FOLLOW_expr_in_if_r1282);
            e2=expr();

            state._fsp--;
            if (state.failed) return retval;
            pushFollow(FOLLOW_expr_in_if_r1286);
            e3=expr();

            state._fsp--;
            if (state.failed) return retval;

            match(input, Token.UP, null); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

                  retval.result = new cond((IF_ST32!=null?IF_ST32.getLine():0), (e1!=null?e1.result:null), (e2!=null?e2.result:null), (e3!=null?e3.result:null));
                  retval.returnType = (e2!=null?e2.returnType:null);
                
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "if_r"

    public static class case_r_return extends TreeRuleReturnScope {
        public typcase result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "case_r"
    // ./src/COOLTreeChecker.g:529:1: case_r returns [typcase result, AbstractSymbol returnType] : ^( CASE_ST e1= expr ( ID TYPE e2= expr )+ ) ;
    public final COOLTreeChecker.case_r_return case_r() throws RecognitionException {
        COOLTreeChecker.case_r_return retval = new COOLTreeChecker.case_r_return();
        retval.start = input.LT(1);

        CommonTree CASE_ST33=null;
        CommonTree ID34=null;
        CommonTree TYPE35=null;
        COOLTreeChecker.expr_return e1 = null;

        COOLTreeChecker.expr_return e2 = null;



          Cases cases = null;

        try {
            // ./src/COOLTreeChecker.g:533:3: ( ^( CASE_ST e1= expr ( ID TYPE e2= expr )+ ) )
            // ./src/COOLTreeChecker.g:534:3: ^( CASE_ST e1= expr ( ID TYPE e2= expr )+ )
            {
            CASE_ST33=(CommonTree)match(input,CASE_ST,FOLLOW_CASE_ST_in_case_r1316); if (state.failed) return retval;

            match(input, Token.DOWN, null); if (state.failed) return retval;
            pushFollow(FOLLOW_expr_in_case_r1320);
            e1=expr();

            state._fsp--;
            if (state.failed) return retval;
            if ( state.backtracking==0 ) {

                  cases = new Cases((CASE_ST33!=null?CASE_ST33.getLine():0));
                  retval.result = new typcase((CASE_ST33!=null?CASE_ST33.getLine():0), (e1!=null?e1.result:null), cases);
                
            }
            // ./src/COOLTreeChecker.g:538:5: ( ID TYPE e2= expr )+
            int cnt30=0;
            loop30:
            do {
                int alt30=2;
                int LA30_0 = input.LA(1);

                if ( (LA30_0==ID) ) {
                    alt30=1;
                }


                switch (alt30) {
            	case 1 :
            	    // ./src/COOLTreeChecker.g:538:6: ID TYPE e2= expr
            	    {
            	    ID34=(CommonTree)match(input,ID,FOLLOW_ID_in_case_r1329); if (state.failed) return retval;
            	    TYPE35=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_case_r1331); if (state.failed) return retval;
            	    pushFollow(FOLLOW_expr_in_case_r1335);
            	    e2=expr();

            	    state._fsp--;
            	    if (state.failed) return retval;
            	    if ( state.backtracking==0 ) {

            	              branch br = new branch((ID34!=null?ID34.getLine():0),
            	                AbstractTable.idtable.addString((ID34!=null?ID34.getText():null)),
            	                AbstractTable.idtable.addString((TYPE35!=null?TYPE35.getText():null)),
            	                (e2!=null?e2.result:null));
            	              cases.appendElement(br);
            	            
            	    }

            	    }
            	    break;

            	default :
            	    if ( cnt30 >= 1 ) break loop30;
            	    if (state.backtracking>0) {state.failed=true; return retval;}
                        EarlyExitException eee =
                            new EarlyExitException(30, input);
                        throw eee;
                }
                cnt30++;
            } while (true);


            match(input, Token.UP, null); if (state.failed) return retval;

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "case_r"

    public static class new_r_return extends TreeRuleReturnScope {
        public new_ result;
        public AbstractSymbol returnType;
    };

    // $ANTLR start "new_r"
    // ./src/COOLTreeChecker.g:550:1: new_r returns [new_ result, AbstractSymbol returnType] : ^( NEW_ST TYPE ) ;
    public final COOLTreeChecker.new_r_return new_r() throws RecognitionException {
        COOLTreeChecker.new_r_return retval = new COOLTreeChecker.new_r_return();
        retval.start = input.LT(1);

        CommonTree TYPE36=null;
        CommonTree NEW_ST37=null;

        try {
            // ./src/COOLTreeChecker.g:551:3: ( ^( NEW_ST TYPE ) )
            // ./src/COOLTreeChecker.g:552:3: ^( NEW_ST TYPE )
            {
            NEW_ST37=(CommonTree)match(input,NEW_ST,FOLLOW_NEW_ST_in_new_r1374); if (state.failed) return retval;

            match(input, Token.DOWN, null); if (state.failed) return retval;
            TYPE36=(CommonTree)match(input,TYPE,FOLLOW_TYPE_in_new_r1376); if (state.failed) return retval;

            match(input, Token.UP, null); if (state.failed) return retval;
            if ( state.backtracking==0 ) {

                  retval.returnType = AbstractTable.idtable.addString((TYPE36!=null?TYPE36.getText():null));
                  retval.result = new new_((NEW_ST37!=null?NEW_ST37.getLine():0), AbstractTable.idtable.addString((TYPE36!=null?TYPE36.getText():null)));
                
            }

            }

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end "new_r"

    // $ANTLR start synpred1_COOLTreeChecker
    public final void synpred1_COOLTreeChecker_fragment() throws RecognitionException {   
        // ./src/COOLTreeChecker.g:299:3: ( ^( op_bin expr expr ) )
        // ./src/COOLTreeChecker.g:299:4: ^( op_bin expr expr )
        {
        pushFollow(FOLLOW_op_bin_in_synpred1_COOLTreeChecker750);
        op_bin();

        state._fsp--;
        if (state.failed) return ;

        match(input, Token.DOWN, null); if (state.failed) return ;
        pushFollow(FOLLOW_expr_in_synpred1_COOLTreeChecker752);
        expr();

        state._fsp--;
        if (state.failed) return ;
        pushFollow(FOLLOW_expr_in_synpred1_COOLTreeChecker754);
        expr();

        state._fsp--;
        if (state.failed) return ;

        match(input, Token.UP, null); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred1_COOLTreeChecker

    // $ANTLR start synpred2_COOLTreeChecker
    public final void synpred2_COOLTreeChecker_fragment() throws RecognitionException {   
        // ./src/COOLTreeChecker.g:348:3: ( '<=' )
        // ./src/COOLTreeChecker.g:348:4: '<='
        {
        match(input,54,FOLLOW_54_in_synpred2_COOLTreeChecker902); if (state.failed) return ;

        }
    }
    // $ANTLR end synpred2_COOLTreeChecker

    // Delegated rules

    public final boolean synpred1_COOLTreeChecker() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred1_COOLTreeChecker_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }
    public final boolean synpred2_COOLTreeChecker() {
        state.backtracking++;
        int start = input.mark();
        try {
            synpred2_COOLTreeChecker_fragment(); // can never throw exception
        } catch (RecognitionException re) {
            System.err.println("impossible: "+re);
        }
        boolean success = !state.failed;
        input.rewind(start);
        state.backtracking--;
        state.failed=false;
        return success;
    }


    protected DFA18 dfa18 = new DFA18(this);
    protected DFA21 dfa21 = new DFA21(this);
    static final String DFA18_eotS =
        "\20\uffff";
    static final String DFA18_eofS =
        "\20\uffff";
    static final String DFA18_minS =
        "\1\6\1\2\15\uffff\1\6";
    static final String DFA18_maxS =
        "\1\77\1\2\15\uffff\1\77";
    static final String DFA18_acceptS =
        "\2\uffff\1\1\1\2\1\3\1\4\1\5\1\6\1\7\1\10\1\11\1\12\1\13\1\14\1"+
        "\15\1\uffff";
    static final String DFA18_specialS =
        "\20\uffff}>";
    static final String[] DFA18_transitionS = {
            "\1\4\4\uffff\1\1\12\uffff\1\10\2\7\1\5\1\11\1\12\1\6\1\16\1"+
            "\14\3\uffff\1\13\2\uffff\1\15\2\uffff\1\2\6\uffff\1\3\5\uffff"+
            "\11\7\2\4",
            "\1\17",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\4\17\uffff\1\10\2\7\1\5\1\11\1\12\1\6\1\16\1\14\3\uffff"+
            "\1\13\2\uffff\1\15\2\uffff\1\2\6\uffff\1\3\5\uffff\11\7\2\4"
    };

    static final short[] DFA18_eot = DFA.unpackEncodedString(DFA18_eotS);
    static final short[] DFA18_eof = DFA.unpackEncodedString(DFA18_eofS);
    static final char[] DFA18_min = DFA.unpackEncodedStringToUnsignedChars(DFA18_minS);
    static final char[] DFA18_max = DFA.unpackEncodedStringToUnsignedChars(DFA18_maxS);
    static final short[] DFA18_accept = DFA.unpackEncodedString(DFA18_acceptS);
    static final short[] DFA18_special = DFA.unpackEncodedString(DFA18_specialS);
    static final short[][] DFA18_transition;

    static {
        int numStates = DFA18_transitionS.length;
        DFA18_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA18_transition[i] = DFA.unpackEncodedString(DFA18_transitionS[i]);
        }
    }

    class DFA18 extends DFA {

        public DFA18(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 18;
            this.eot = DFA18_eot;
            this.eof = DFA18_eof;
            this.min = DFA18_min;
            this.max = DFA18_max;
            this.accept = DFA18_accept;
            this.special = DFA18_special;
            this.transition = DFA18_transition;
        }
        public String getDescription() {
            return "165:1: expr returns [Expression result, AbstractSymbol returnType] : ( ( ^( EXPR_T l= let ) | l= let ) | ( ^( EXPR_T bl= block ) | bl= block ) | ( ^( EXPR_T c= call ) | c= call ) | ( ^( EXPR_T i= INTEGER ) | i= INTEGER ) | ( ^( EXPR_T s= STRING ) | s= STRING ) | ( ^( EXPR_T o= op ) | o= op ) | ( ^( EXPR_T id= ID ) | id= ID ) | ( ^( EXPR_T b= TRUE_ST ) | b= TRUE_ST ) | ( ^( EXPR_T b= FALSE_ST ) | b= FALSE_ST ) | ( ^( EXPR_T w= while_r ) | w= while_r ) | ( ^( EXPR_T if_r_= if_r ) | if_r_= if_r ) | ( ^( EXPR_T case_r_= case_r ) | case_r_= case_r ) | ( ^( EXPR_T new_r_= new_r ) | new_r_= new_r ) );";
        }
    }
    static final String DFA21_eotS =
        "\64\uffff";
    static final String DFA21_eofS =
        "\64\uffff";
    static final String DFA21_minS =
        "\1\27\2\2\4\uffff\3\6\31\uffff\1\3\7\uffff\1\3\6\uffff\1\0\1\uffff";
    static final String DFA21_maxS =
        "\1\75\2\2\4\uffff\3\77\31\uffff\1\3\7\uffff\1\3\6\uffff\1\0\1\uffff";
    static final String DFA21_acceptS =
        "\3\uffff\1\3\1\4\1\5\1\6\3\uffff\31\1\1\uffff\7\1\1\uffff\6\1\1"+
        "\uffff\1\2";
    static final String DFA21_specialS =
        "\7\uffff\1\0\1\3\1\2\50\uffff\1\1\1\uffff}>";
    static final String[] DFA21_transitionS = {
            "\1\4\1\5\34\uffff\1\6\1\1\6\2\1\3",
            "\1\7",
            "\1\7",
            "",
            "",
            "",
            "",
            "\1\15\4\uffff\1\12\12\uffff\1\11\1\24\1\25\1\10\1\27\1\30\1"+
            "\20\1\34\1\32\3\uffff\1\31\2\uffff\1\33\2\uffff\1\13\6\uffff"+
            "\1\14\5\uffff\1\26\1\21\6\22\1\23\1\17\1\16",
            "\1\40\4\uffff\1\35\12\uffff\1\53\1\50\1\51\1\43\1\54\1\55\1"+
            "\44\1\61\1\57\3\uffff\1\56\2\uffff\1\60\2\uffff\1\36\6\uffff"+
            "\1\37\5\uffff\1\52\1\45\6\46\1\47\1\42\1\41",
            "\1\40\4\uffff\1\35\12\uffff\1\53\1\50\1\51\1\43\1\54\1\55\1"+
            "\44\1\61\1\57\3\uffff\1\56\2\uffff\1\60\2\uffff\1\36\6\uffff"+
            "\1\37\5\uffff\1\52\1\45\6\46\1\47\1\42\1\41",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\62",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\62",
            "",
            "",
            "",
            "",
            "",
            "",
            "\1\uffff",
            ""
    };

    static final short[] DFA21_eot = DFA.unpackEncodedString(DFA21_eotS);
    static final short[] DFA21_eof = DFA.unpackEncodedString(DFA21_eofS);
    static final char[] DFA21_min = DFA.unpackEncodedStringToUnsignedChars(DFA21_minS);
    static final char[] DFA21_max = DFA.unpackEncodedStringToUnsignedChars(DFA21_maxS);
    static final short[] DFA21_accept = DFA.unpackEncodedString(DFA21_acceptS);
    static final short[] DFA21_special = DFA.unpackEncodedString(DFA21_specialS);
    static final short[][] DFA21_transition;

    static {
        int numStates = DFA21_transitionS.length;
        DFA21_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA21_transition[i] = DFA.unpackEncodedString(DFA21_transitionS[i]);
        }
    }

    class DFA21 extends DFA {

        public DFA21(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 21;
            this.eot = DFA21_eot;
            this.eof = DFA21_eof;
            this.min = DFA21_min;
            this.max = DFA21_max;
            this.accept = DFA21_accept;
            this.special = DFA21_special;
            this.transition = DFA21_transition;
        }
        public String getDescription() {
            return "297:1: op returns [Expression result, AbstractSymbol returnType] : ( ( ^( op_bin expr expr ) )=> ^(o= op_bin e1= expr e2= expr ) | ^(o= op_bin p1= adapt_id_integer p2= adapt_id_integer ) | ^(e= '~' expr ) | ^( NOT_ST expr ) | ^( ISVOID_ST expr ) | ^(assignStr= '<-' ID expr ) );";
        }
        public int specialStateTransition(int s, IntStream _input) throws NoViableAltException {
            TreeNodeStream input = (TreeNodeStream)_input;
        	int _s = s;
            switch ( s ) {
                    case 0 : 
                        int LA21_7 = input.LA(1);

                         
                        int index21_7 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA21_7==INTEGER) ) {s = 8;}

                        else if ( (LA21_7==ID) ) {s = 9;}

                        else if ( (LA21_7==EXPR_T) && (synpred1_COOLTreeChecker())) {s = 10;}

                        else if ( (LA21_7==LET_ST) && (synpred1_COOLTreeChecker())) {s = 11;}

                        else if ( (LA21_7==47) && (synpred1_COOLTreeChecker())) {s = 12;}

                        else if ( (LA21_7==CALL_T) && (synpred1_COOLTreeChecker())) {s = 13;}

                        else if ( (LA21_7==63) && (synpred1_COOLTreeChecker())) {s = 14;}

                        else if ( (LA21_7==62) && (synpred1_COOLTreeChecker())) {s = 15;}

                        else if ( (LA21_7==STRING) && (synpred1_COOLTreeChecker())) {s = 16;}

                        else if ( (LA21_7==54) && (synpred1_COOLTreeChecker())) {s = 17;}

                        else if ( ((LA21_7>=55 && LA21_7<=60)) && (synpred1_COOLTreeChecker())) {s = 18;}

                        else if ( (LA21_7==61) && (synpred1_COOLTreeChecker())) {s = 19;}

                        else if ( (LA21_7==NOT_ST) && (synpred1_COOLTreeChecker())) {s = 20;}

                        else if ( (LA21_7==ISVOID_ST) && (synpred1_COOLTreeChecker())) {s = 21;}

                        else if ( (LA21_7==53) && (synpred1_COOLTreeChecker())) {s = 22;}

                        else if ( (LA21_7==TRUE_ST) && (synpred1_COOLTreeChecker())) {s = 23;}

                        else if ( (LA21_7==FALSE_ST) && (synpred1_COOLTreeChecker())) {s = 24;}

                        else if ( (LA21_7==WHILE_ST) && (synpred1_COOLTreeChecker())) {s = 25;}

                        else if ( (LA21_7==IF_ST) && (synpred1_COOLTreeChecker())) {s = 26;}

                        else if ( (LA21_7==CASE_ST) && (synpred1_COOLTreeChecker())) {s = 27;}

                        else if ( (LA21_7==NEW_ST) && (synpred1_COOLTreeChecker())) {s = 28;}

                         
                        input.seek(index21_7);
                        if ( s>=0 ) return s;
                        break;
                    case 1 : 
                        int LA21_50 = input.LA(1);

                         
                        int index21_50 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (synpred1_COOLTreeChecker()) ) {s = 49;}

                        else if ( (true) ) {s = 51;}

                         
                        input.seek(index21_50);
                        if ( s>=0 ) return s;
                        break;
                    case 2 : 
                        int LA21_9 = input.LA(1);

                         
                        int index21_9 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA21_9==INTEGER) ) {s = 35;}

                        else if ( (LA21_9==ID) ) {s = 43;}

                        else if ( (LA21_9==EXPR_T) && (synpred1_COOLTreeChecker())) {s = 29;}

                        else if ( (LA21_9==LET_ST) && (synpred1_COOLTreeChecker())) {s = 30;}

                        else if ( (LA21_9==47) && (synpred1_COOLTreeChecker())) {s = 31;}

                        else if ( (LA21_9==CALL_T) && (synpred1_COOLTreeChecker())) {s = 32;}

                        else if ( (LA21_9==63) && (synpred1_COOLTreeChecker())) {s = 33;}

                        else if ( (LA21_9==62) && (synpred1_COOLTreeChecker())) {s = 34;}

                        else if ( (LA21_9==STRING) && (synpred1_COOLTreeChecker())) {s = 36;}

                        else if ( (LA21_9==54) && (synpred1_COOLTreeChecker())) {s = 37;}

                        else if ( ((LA21_9>=55 && LA21_9<=60)) && (synpred1_COOLTreeChecker())) {s = 38;}

                        else if ( (LA21_9==61) && (synpred1_COOLTreeChecker())) {s = 39;}

                        else if ( (LA21_9==NOT_ST) && (synpred1_COOLTreeChecker())) {s = 40;}

                        else if ( (LA21_9==ISVOID_ST) && (synpred1_COOLTreeChecker())) {s = 41;}

                        else if ( (LA21_9==53) && (synpred1_COOLTreeChecker())) {s = 42;}

                        else if ( (LA21_9==TRUE_ST) && (synpred1_COOLTreeChecker())) {s = 44;}

                        else if ( (LA21_9==FALSE_ST) && (synpred1_COOLTreeChecker())) {s = 45;}

                        else if ( (LA21_9==WHILE_ST) && (synpred1_COOLTreeChecker())) {s = 46;}

                        else if ( (LA21_9==IF_ST) && (synpred1_COOLTreeChecker())) {s = 47;}

                        else if ( (LA21_9==CASE_ST) && (synpred1_COOLTreeChecker())) {s = 48;}

                        else if ( (LA21_9==NEW_ST) && (synpred1_COOLTreeChecker())) {s = 49;}

                         
                        input.seek(index21_9);
                        if ( s>=0 ) return s;
                        break;
                    case 3 : 
                        int LA21_8 = input.LA(1);

                         
                        int index21_8 = input.index();
                        input.rewind();
                        s = -1;
                        if ( (LA21_8==EXPR_T) && (synpred1_COOLTreeChecker())) {s = 29;}

                        else if ( (LA21_8==LET_ST) && (synpred1_COOLTreeChecker())) {s = 30;}

                        else if ( (LA21_8==47) && (synpred1_COOLTreeChecker())) {s = 31;}

                        else if ( (LA21_8==CALL_T) && (synpred1_COOLTreeChecker())) {s = 32;}

                        else if ( (LA21_8==63) && (synpred1_COOLTreeChecker())) {s = 33;}

                        else if ( (LA21_8==62) && (synpred1_COOLTreeChecker())) {s = 34;}

                        else if ( (LA21_8==INTEGER) ) {s = 35;}

                        else if ( (LA21_8==STRING) && (synpred1_COOLTreeChecker())) {s = 36;}

                        else if ( (LA21_8==54) && (synpred1_COOLTreeChecker())) {s = 37;}

                        else if ( ((LA21_8>=55 && LA21_8<=60)) && (synpred1_COOLTreeChecker())) {s = 38;}

                        else if ( (LA21_8==61) && (synpred1_COOLTreeChecker())) {s = 39;}

                        else if ( (LA21_8==NOT_ST) && (synpred1_COOLTreeChecker())) {s = 40;}

                        else if ( (LA21_8==ISVOID_ST) && (synpred1_COOLTreeChecker())) {s = 41;}

                        else if ( (LA21_8==53) && (synpred1_COOLTreeChecker())) {s = 42;}

                        else if ( (LA21_8==ID) ) {s = 43;}

                        else if ( (LA21_8==TRUE_ST) && (synpred1_COOLTreeChecker())) {s = 44;}

                        else if ( (LA21_8==FALSE_ST) && (synpred1_COOLTreeChecker())) {s = 45;}

                        else if ( (LA21_8==WHILE_ST) && (synpred1_COOLTreeChecker())) {s = 46;}

                        else if ( (LA21_8==IF_ST) && (synpred1_COOLTreeChecker())) {s = 47;}

                        else if ( (LA21_8==CASE_ST) && (synpred1_COOLTreeChecker())) {s = 48;}

                        else if ( (LA21_8==NEW_ST) && (synpred1_COOLTreeChecker())) {s = 49;}

                         
                        input.seek(index21_8);
                        if ( s>=0 ) return s;
                        break;
            }
            if (state.backtracking>0) {state.failed=true; return -1;}
            NoViableAltException nvae =
                new NoViableAltException(getDescription(), 21, _s, input);
            error(nvae);
            throw nvae;
        }
    }
 

    public static final BitSet FOLLOW_classdef_in_program60 = new BitSet(new long[]{0x0000000000000012L});
    public static final BitSet FOLLOW_CLASS_T_in_classdef87 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_classdef91 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_features_in_classdef93 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CLASS_T_in_classdef107 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_classdef111 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_classdef115 = new BitSet(new long[]{0x0000000000000080L});
    public static final BitSet FOLLOW_features_in_classdef117 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FEATURES_T_in_features147 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_feature_in_features163 = new BitSet(new long[]{0x0000000000008208L});
    public static final BitSet FOLLOW_METHOD_T_in_feature197 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_feature201 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_feature205 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_formals_in_feature207 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_feature209 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ATTR_T_in_feature223 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_feature227 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_feature231 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ATTR_T_in_feature245 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_feature249 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_feature253 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_feature257 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_EXPR_T_in_expr283 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_let_in_expr287 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_let_in_expr294 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr309 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_block_in_expr313 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_block_in_expr320 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr335 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_call_in_expr339 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_call_in_expr346 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr361 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_INTEGER_in_expr365 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTEGER_in_expr372 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr387 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_STRING_in_expr391 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_STRING_in_expr398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr413 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_op_in_expr417 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_op_in_expr424 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr439 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_expr443 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ID_in_expr450 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr465 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TRUE_ST_in_expr469 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_TRUE_ST_in_expr476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr491 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_FALSE_ST_in_expr495 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_FALSE_ST_in_expr502 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr517 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_while_r_in_expr521 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_while_r_in_expr528 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr543 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_if_r_in_expr547 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_if_r_in_expr554 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr569 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_case_r_in_expr573 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_case_r_in_expr580 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_EXPR_T_in_expr595 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_new_r_in_expr599 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_new_r_in_expr606 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_FORMALS_T_in_formals631 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_formal_in_formals640 = new BitSet(new long[]{0x0000000000002008L});
    public static final BitSet FOLLOW_TYPE_ID_in_formal680 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_formal684 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_formal688 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_INTEGER_in_adapt_id_integer712 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_ID_in_adapt_id_integer722 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_op_bin_in_op765 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_op771 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_op777 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_op_bin_in_op795 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_adapt_id_integer_in_op801 = new BitSet(new long[]{0x0000000002400000L});
    public static final BitSet FOLLOW_adapt_id_integer_in_op807 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_61_in_op823 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_op825 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_NOT_ST_in_op839 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_op841 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_ISVOID_ST_in_op855 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_op857 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_53_in_op873 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_op875 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_op877 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_54_in_op_bin911 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_op_bin927 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_47_in_block980 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_block990 = new BitSet(new long[]{0xFFE081247FC00848L});
    public static final BitSet FOLLOW_CALL_T_in_call1029 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_call1038 = new BitSet(new long[]{0xFFE081247FC00848L});
    public static final BitSet FOLLOW_expr_in_call1049 = new BitSet(new long[]{0xFFE081247FC00848L});
    public static final BitSet FOLLOW_63_in_call1069 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_call1079 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_ID_in_call1081 = new BitSet(new long[]{0xFFE081247FC00848L});
    public static final BitSet FOLLOW_expr_in_call1096 = new BitSet(new long[]{0xFFE081247FC00848L});
    public static final BitSet FOLLOW_62_in_call1123 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_call1125 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_call1127 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_LET_ST_in_let1164 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_ID_in_let1168 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_let1172 = new BitSet(new long[]{0xFFE481247FC00840L});
    public static final BitSet FOLLOW_53_in_let1175 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_let1179 = new BitSet(new long[]{0xFFE481247FC00840L});
    public static final BitSet FOLLOW_50_in_let1184 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_ID_in_let1188 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_let1192 = new BitSet(new long[]{0xFFE481247FC00840L});
    public static final BitSet FOLLOW_53_in_let1195 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_let1199 = new BitSet(new long[]{0xFFE481247FC00840L});
    public static final BitSet FOLLOW_expr_in_let1216 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_WHILE_ST_in_while_r1241 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_while_r1245 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_while_r1249 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_IF_ST_in_if_r1274 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_if_r1278 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_if_r1282 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_if_r1286 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_CASE_ST_in_case_r1316 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_case_r1320 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_ID_in_case_r1329 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_TYPE_in_case_r1331 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_case_r1335 = new BitSet(new long[]{0x0000000000400008L});
    public static final BitSet FOLLOW_NEW_ST_in_new_r1374 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_TYPE_in_new_r1376 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_op_bin_in_synpred1_COOLTreeChecker750 = new BitSet(new long[]{0x0000000000000004L});
    public static final BitSet FOLLOW_expr_in_synpred1_COOLTreeChecker752 = new BitSet(new long[]{0xFFE081247FC00840L});
    public static final BitSet FOLLOW_expr_in_synpred1_COOLTreeChecker754 = new BitSet(new long[]{0x0000000000000008L});
    public static final BitSet FOLLOW_54_in_synpred2_COOLTreeChecker902 = new BitSet(new long[]{0x0000000000000002L});

}